package com.trans.locomotive.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.trans.locomotive.dao.LocomotiveDao;
import com.trans.locomotive.db.DBConnection;

public class LocomotiveUtility {
	
	final static Logger logger = Logger.getLogger(LocomotiveUtility.class);
			
	public static List<LocomotiveDao> getData(){
		List<LocomotiveDao> data = null;
		LocomotiveDao dao = null;
		//TODO: change this if you plan to use JNDI
		Connection conn = DBConnection.getInstance().getDBConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sqlQuery = "select * from ras_ml.ras2_loco_base_rcc_summary_all Limit 1000" ;

		if(conn != null){
			data = new ArrayList<LocomotiveDao>();
			try{
				pstmt = conn.prepareStatement(sqlQuery);
				rs = pstmt.executeQuery();
				while(rs.next()){
					dao = new LocomotiveDao();
					dao.setFail_date(rs.getString("fail_date"));
					dao.setCustomer_name(rs.getString("customer_name"));
					dao.setFleet_name(rs.getString("fleet_name"));
					dao.setLocomotive_model_code(rs.getString("locomotive_model_code"));
					dao.setLocomotive_type_code(rs.getString("locomotive_type_code"));
					dao.setTier(rs.getString("tier"));
					dao.setInfancy_flg(rs.getString("infancy_flg"));
					dao.setCust_fail_type(rs.getString("cust_fail_type"));
					dao.setRoot_cause_code(rs.getString("root_cause_code"));
					dao.setSymptom_code(rs.getString("symptom_code"));
					dao.setGe_fail_type(rs.getString("ge_fail_type"));
					dao.setCoe(rs.getString("coe"));
					dao.setReport_type_code(rs.getString("report_type_code"));
					dao.setLoco_year_base_id(rs.getInt("loco_year_base_id"));
					dao.setLoco_yr(rs.getString("loco_yr"));
					dao.setFail_count(rs.getInt("fail_count"));
					
					data.add(dao);
				}				
			}catch(SQLException sqle){
				sqle.getMessage();
			}finally{
				try{
					if(pstmt != null)
						pstmt.close();
					if(rs != null)
						rs.close();
					if(conn != null)
						conn.close();
				}catch (SQLException sqle){
					logger.error("Could not close the connection in the end.");
				}
			}
		}else{
			logger.error("Could not get database connection. Check connection details.");
		}
		/*if(data.size() < 1 || data.isEmpty() || data == null ){
			logger.warn("No data retrieved for the query.");
		}*/
		System.out.println(data);
		return data;
	}
}

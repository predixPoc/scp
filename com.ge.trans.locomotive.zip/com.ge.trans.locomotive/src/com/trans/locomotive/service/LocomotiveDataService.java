package com.trans.locomotive.service;


import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.log4j.Logger;

import com.trans.locomotive.util.LocomotiveUtility;


@Path("LocomotiveService")
public class LocomotiveDataService {
	final static Logger logger = Logger.getLogger(LocomotiveDataService.class);

	
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	public Response getServiceRequestHistoryDetails(){
		System.out.println("in Response....");
		return Response.ok(LocomotiveUtility.getData()).build();
	}
	

}

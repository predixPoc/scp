package com.trans.locomotive.dao;

public class LocomotiveDao {

	
	/**
	 * @return the fail_date
	 */
	public String getFail_date() {
		return fail_date;
	}
	/**
	 * @param fail_date the fail_date to set
	 */
	public void setFail_date(String fail_date) {
		this.fail_date = fail_date;
	}
	/**
	 * @return the customer_name
	 */
	public String getCustomer_name() {
		return customer_name;
	}
	/**
	 * @param customer_name the customer_name to set
	 */
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	/**
	 * @return the fleet_name
	 */
	public String getFleet_name() {
		return fleet_name;
	}
	/**
	 * @param fleet_name the fleet_name to set
	 */
	public void setFleet_name(String fleet_name) {
		this.fleet_name = fleet_name;
	}
	/**
	 * @return the locomotive_model_code
	 */
	public String getLocomotive_model_code() {
		return locomotive_model_code;
	}
	/**
	 * @param locomotive_model_code the locomotive_model_code to set
	 */
	public void setLocomotive_model_code(String locomotive_model_code) {
		this.locomotive_model_code = locomotive_model_code;
	}
	/**
	 * @return the locomotive_type_code
	 */
	public String getLocomotive_type_code() {
		return locomotive_type_code;
	}
	/**
	 * @param locomotive_type_code the locomotive_type_code to set
	 */
	public void setLocomotive_type_code(String locomotive_type_code) {
		this.locomotive_type_code = locomotive_type_code;
	}
	/**
	 * @return the tier
	 */
	public String getTier() {
		return tier;
	}
	/**
	 * @param tier the tier to set
	 */
	public void setTier(String tier) {
		this.tier = tier;
	}
	/**
	 * @return the infancy_flg
	 */
	public String getInfancy_flg() {
		return infancy_flg;
	}
	/**
	 * @param infancy_flg the infancy_flg to set
	 */
	public void setInfancy_flg(String infancy_flg) {
		this.infancy_flg = infancy_flg;
	}
	/**
	 * @return the cust_fail_type
	 */
	public String getCust_fail_type() {
		return cust_fail_type;
	}
	/**
	 * @param cust_fail_type the cust_fail_type to set
	 */
	public void setCust_fail_type(String cust_fail_type) {
		this.cust_fail_type = cust_fail_type;
	}
	/**
	 * @return the root_cause_code
	 */
	public String getRoot_cause_code() {
		return root_cause_code;
	}
	/**
	 * @param root_cause_code the root_cause_code to set
	 */
	public void setRoot_cause_code(String root_cause_code) {
		this.root_cause_code = root_cause_code;
	}
	/**
	 * @return the symptom_code
	 */
	public String getSymptom_code() {
		return symptom_code;
	}
	/**
	 * @param symptom_code the symptom_code to set
	 */
	public void setSymptom_code(String symptom_code) {
		this.symptom_code = symptom_code;
	}
	/**
	 * @return the ge_fail_type
	 */
	public String getGe_fail_type() {
		return ge_fail_type;
	}
	/**
	 * @param ge_fail_type the ge_fail_type to set
	 */
	public void setGe_fail_type(String ge_fail_type) {
		this.ge_fail_type = ge_fail_type;
	}
	/**
	 * @return the coe
	 */
	public String getCoe() {
		return coe;
	}
	/**
	 * @param coe the coe to set
	 */
	public void setCoe(String coe) {
		this.coe = coe;
	}
	/**
	 * @return the report_type_code
	 */
	public String getReport_type_code() {
		return report_type_code;
	}
	/**
	 * @param report_type_code the report_type_code to set
	 */
	public void setReport_type_code(String report_type_code) {
		this.report_type_code = report_type_code;
	}
	/**
	 * @return the loco_year_base_id
	 */
	public int getLoco_year_base_id() {
		return loco_year_base_id;
	}
	/**
	 * @param loco_year_base_id the loco_year_base_id to set
	 */
	public void setLoco_year_base_id(int loco_year_base_id) {
		this.loco_year_base_id = loco_year_base_id;
	}
	/**
	 * @return the loco_yr
	 */
	public String getLoco_yr() {
		return loco_yr;
	}
	/**
	 * @param loco_yr the loco_yr to set
	 */
	public void setLoco_yr(String loco_yr) {
		this.loco_yr = loco_yr;
	}
	/**
	 * @return the fail_count
	 */
	public int getFail_count() {
		return fail_count;
	}
	/**
	 * @param fail_count the fail_count to set
	 */
	public void setFail_count(int fail_count) {
		this.fail_count = fail_count;
	}
	private String fail_date;
	private String customer_name;
	private String fleet_name;
	private String locomotive_model_code;
	private String locomotive_type_code;
	private String tier;
	private String infancy_flg;
	private String cust_fail_type;
	private String root_cause_code;
	private String symptom_code;
	private String ge_fail_type;
	private String coe;
	private String report_type_code;
	private int loco_year_base_id;
	private String loco_yr;
	private int fail_count;

	
}

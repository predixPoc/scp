package com.trans.locomotive.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;


public class DBConnection {
	final static Logger logger = Logger.getLogger(DBConnection.class);

	static DBConnection dbConnInstance = null;

	Connection connection = null;

	//JNDI connection variables
	Context initialContext = null;	
	DataSource datasource = null;
	String DATASOURCE_CONTEXT = "java:comp/env/jdbc/";
	//TODO: move this to the properties file
	String contextName = "testdb";
	//END of JNDI

	//postgres typical driver connectivity
	
	private static String POSTGRES_URL;
	private static String POSTGRES_UID;
	private static String POSTGRES_PWD;
	
	//TODO: move this to the properties file
	String pgJdbcUrl = "jdbc:postgresql://localhost:5432/testdb";
	String pgUser = "postgres";
	String pgPassword = "admin";
	
	//end of postgres
	
	//TODO: NEED TO READ CONFIG FILE FROM PATH
	private void loadPropertiesFile(){		
			Properties props = new Properties();
			try{
				props.load(DBConnection.class.getClassLoader().getResourceAsStream("dbconfig.properties"));
				System.out.println("loading properties...");
				POSTGRES_URL = props.getProperty("POSTGRES_URL");
				POSTGRES_UID = props.getProperty("POSTGRES_UID");
				POSTGRES_PWD = props.getProperty("POSTGRES_PWD");				
				/*System.out.println(POSTGRES_URL+" -- "+ POSTGRES_UID);*/
			}catch(Exception e){
				e.printStackTrace();
		}
	}

	public static DBConnection getInstance(){
		if(dbConnInstance == null){
			dbConnInstance = new DBConnection();
		}
		return dbConnInstance;
	}

	//DBConnection using typical driver connection
	public Connection getDBConnection(){
		loadPropertiesFile();
		try{
			Class.forName("org.postgresql.Driver");
			connection = DriverManager.getConnection(POSTGRES_URL, POSTGRES_UID, POSTGRES_PWD);
		}catch(ClassNotFoundException cnfe){
			logger.error(cnfe.getMessage());
		}catch(SQLException sqle){
			logger.error(sqle.getMessage());
		}
		if(connection == null)
			logger.error("Could not get DB connection, please look into the connection properties.");

		return connection;
	}

	//DBConnection using JNDI
	public Connection getJNDIConnection(){		
		try {
			initialContext = new InitialContext();
			datasource = (DataSource)initialContext.lookup(DATASOURCE_CONTEXT+contextName);
			if (datasource != null) {
				connection = datasource.getConnection();
			}else {
				logger.fatal("Could not look up the datasource.");
			}			
		}catch (NamingException ne ) {
			logger.error(ne.getMessage());
		}catch(SQLException sqle){
			logger.error(sqle.getMessage());
		}
		if(connection == null)
			logger.error("Could not get JNDI connection, please look into the connection properties.");

		return connection;
	}	

	/*//TODO: commented temporary main method delete after connection test is done
	public static void main(String[] args){
		Connection conn = DBConnection.getInstance().getDBConnection();
		String query = "select * from testuser";
		PreparedStatement stmt = null;
		String name = null;
		ResultSet rs = null;
		if(conn != null){
			try{
				stmt = conn.prepareStatement(query);
				rs = stmt.executeQuery();
				while (rs.next()) {
					name = rs.getString(1);
					System.out.println(name);
				}
			}catch(SQLException sqle){
				sqle.getMessage();
			}
		}
	}*/

}

jQuery(document).ready(function() {

      jQuery("#invoicepoNumber").val('');
      jQuery("#invoiceAmount").val('');
      jQuery("#invoiceSubmitDt").val('');
      jQuery("#invoiceNumber").val('');
	  jQuery("#invoicepaymentNumber").val('');
	  jQuery("#errorInvoice").text('');
	  jQuery("#errorInvoicePO").text('');
	  jQuery("#errorInvoiceGSL").text('');
	  jQuery("#errorPayment").text('');
	   jQuery("#errorPaymentPO").text('');
	    jQuery("#errorPaymentGSL").text('');
	 // searchInvoiceGridData('','','','','');
	  
	  jQuery("#paymentpoNumber").val('');
	  jQuery("#paymentamount").val('');
	  jQuery("#paymentDate").val('');
	  jQuery("#paymentinvoiceNumber").val('');
      jQuery("#paymentNumber").val('');
	  
	  jQuery("#invoiceNumberRadio").prop("checked", true);
	  jQuery("#paymentNumberRadio").prop("checked", true);
	  
	  jQuery("#invoiceNumber").show();
	jQuery("#invoicepoNumber").hide();
	jQuery("#paymentNumber").show();
	jQuery("#paymentpoNumber").hide();

	
	jQuery("#homeID").click(function(){
		clearPaymentTab();
		clearInvoiceTab();
	
	});
	jQuery("#invoiceIDclick").click(function(){
	clearPaymentTab();
	});
	jQuery("#paymentIDclick").click(function(){
	clearInvoiceTab();
	});
	
    jQuery("#invoiceNumberRadio").click(function(){
		  jQuery("#invoicepoNumber").hide();
		     jQuery("#invoiceNumberID").val('');
			 jQuery("#invoicepoNumber").val('');
		  jQuery("#errorInvoicePO").text('');
        jQuery("#invoiceNumberID").show();
    });
	jQuery("#invoicePoNumberRadio").click(function(){
        jQuery("#invoiceNumberID").hide();
		jQuery("#invoicepoNumber").val('');
		jQuery("#invoiceNumberID").val('');
		jQuery("#errorInvoice").text('');
		  jQuery("#invoicepoNumber").show();
    });
	
	$("#paymentNumberRadio").click(function(){
       $("#paymentpoNumber").hide();
	    $("#paymentNumber").val('');
		$("#paymentpoNumber").val('');
	   jQuery("#errorPaymentPO").text('');
	    $("#paymentNumber").show();
    });
	
	$("#paymentPoNumberRadio").click(function(){
        $("#paymentNumber").hide();
		$("#paymentNumber").val('');
		 $("#paymentpoNumber").val('');
		jQuery("#errorPayment").text('');
		 $("#paymentpoNumber").show();
    });
	

	 
	  //searchPaymentGridData('','','','','','');
	
	 jQuery('[data-toggle="invNmberTooltip"]').tooltip(); 

      
		$("#myTab a").click(function(e){
    	e.preventDefault();
    	$(this).tab('show');
    });
	$('#invoiceNumberID').keyup(function() {
		if( $('#invoiceNumberID').val() !='' || $('#invoicepoNumber').val() !=''){
		jQuery("#errorInvoice").text('');
		}
	})
	$('#invoicepoNumber').keyup(function() {
		if( $('#invoiceNumber').val() !='' || $('#invoicepoNumber').val() !=''){
		jQuery("#errorInvoicePO").text('');
		}
	})

	$('#invoiceVdrGSL').keyup(function() {
		if( $('#invoiceVdrGSL').val() !='' || $('#invoicepoNumber').val() !=''){
		jQuery("#errorInvoiceGSL").text('');
		}
	})
	$("#invoiceSubmitID").click(function(event){
		var searchinvoiceVdrGSL = jQuery("#invoiceVdrGSL").val();
		var searchinvoicepoNumber = jQuery("#invoicepoNumber").val();
		var searchinvoiceAmount = jQuery("#invoiceAmount").val();
		var searchinvoiceSubmitDt = jQuery("#invoiceFromSubmitDt").val();
		if (searchinvoiceSubmitDt != ''){
		console.log('searchinvoiceSubmitDt old '+searchinvoiceSubmitDt);
		searchinvoiceSubmitDt = dateFormatt(searchinvoiceSubmitDt);
		console.log('searchinvoiceSubmitDt New '+searchinvoiceSubmitDt);
		}
		var searchinvoiceNumber = jQuery("#invoiceNumberID").val();
		var searchinvoicepaymentNumber = jQuery("#invoicepaymentNumber").val();
		if(searchinvoiceVdrGSL !='' && (searchinvoicepoNumber !='' || searchinvoiceNumber !=='')){		
		searchInvoiceGridData(searchinvoicepoNumber, searchinvoiceAmount, searchinvoiceSubmitDt, searchinvoiceNumber, searchinvoicepaymentNumber,searchinvoiceVdrGSL);
		}
		if(searchinvoiceVdrGSL == ''){
				jQuery("#errorInvoiceGSL").text('Please enter Vendor GSL.');
			}
			else if ($("#invoiceNumberRadio").prop("checked") && searchinvoiceNumber == '') {
   // do something
			jQuery("#errorInvoice").text('Please enter the Invoice Number');
			}	
			if ($("#invoicePoNumberRadio").prop("checked") && searchinvoicepoNumber == '') 
				{
			jQuery("#errorInvoicePO").text('Please enter the PO Number.');
			}	
	});
	
	
	function clearInvoiceTab(){
		jQuery("#invoiceVdrGSL").val('');
		jQuery("#invoicepoNumber").val('');
		jQuery("#invoiceAmount").val('');
		jQuery("#invoiceFromSubmitDt").val('');
		jQuery("#invoiceNumberID").val('');
		jQuery("#invoicepaymentNumber").val('');
		jQuery("#errorInvoiceGSL").text('');
		jQuery("#errorInvoice").text('');
		jQuery("#errorInvoicePO").text('');
	}
	$("#invoiceClearBtnID").click(function (event) {
		clearInvoiceTab();
  //  searchInvoiceGridData('','','','','','');
	});
	
		$('#paymentpoNumber').keyup(function() {
		if( $('#paymentpoNumber').val() !='' || $('#paymentpoNumber').val() !=''){
		jQuery("#errorPaymentPO").text('');
		}
	})
	$('#paymentNumber').keyup(function() {
		if( $('#paymentNumber').val() !='' || $('#paymentpoNumber').val() !=''){
		jQuery("#errorPayment").text('');
		}
	})
		$('#paymnetVdrGSL').keyup(function() {
		if( $('#paymnetVdrGSL').val() !='' || $('#invoicepoNumber').val() !=''){
		jQuery("#errorPaymentGSL").text('');
		}
	})
	
	$("#paymentSubmitID").click(function(event){
		var searchpaymentVdrGSL = jQuery("#paymnetVdrGSL").val();
		var searchpaymentpoNumber = jQuery("#paymentpoNumber").val();
		var searchpaymentamount = jQuery("#paymentamount").val();
		var searchpaymentDate = jQuery("#paymentDate").val();
		console.log('searchpaymentDate old '+searchpaymentDate);
		if (searchpaymentDate !=''){
		searchpaymentDate = dateFormatt(searchpaymentDate);
		console.log('searchpaymentDate New '+searchpaymentDate);
		}
		var searchpaymentinvoiceNumber = jQuery("#paymentinvoiceNumber").val();
		var searchpaymentNumber = jQuery("#paymentNumber").val();		
		if(searchpaymentVdrGSL !== '' && (searchpaymentpoNumber !='' || searchpaymentNumber !='')){
		searchPaymentGridData(searchpaymentVdrGSL,searchpaymentpoNumber, searchpaymentamount, searchpaymentDate, searchpaymentinvoiceNumber, searchpaymentNumber);
		}	if(searchpaymentVdrGSL == ''){
				jQuery("#errorPaymentGSL").text('Please enter the Vendor GSL.');
			}
			else if ($("#paymentNumberRadio").prop("checked") && searchpaymentNumber == '') {
   // do something
			jQuery("#errorPayment").text('Please enter the Payment Number');
			}	
			if ($("#paymentPoNumberRadio").prop("checked") && searchpaymentpoNumber == '') 
				{
			jQuery("#errorPaymentPO").text('Please enter the PO Number.');
			}	
	
    });
	function clearPaymentTab(){
		jQuery("#paymnetVdrGSL").val('');
     jQuery("#paymentpoNumber").val('');
      jQuery("#paymentamount").val('');
      jQuery("#paymentDate").val('');
      jQuery("#paymentinvoiceNumber").val('');
      jQuery("#paymentNumber").val('');
	  jQuery("#errorPayment").text('');
	   jQuery("#errorPaymentPO").text('');
	    jQuery("#errorPaymentGSL").text('');
	}
	$("#paymentClearBtnID").click(function (event) {
		clearPaymentTab();
	});
	
	function searchInvoiceGridData(searchinvoicepoNumber,searchinvoiceAmount,searchinvoiceSubmitDt,searchinvoiceNumber, searchinvoicepaymentNumber,searchinvoiceVdrGSL){
       var searchitemdata = {poNumber:searchinvoicepoNumber, amount:searchinvoiceAmount, invoiceDate:searchinvoiceSubmitDt, invoiceNumber:searchinvoiceNumber, paymentNumber:searchinvoicepaymentNumber,venderGSL:searchinvoiceVdrGSL};
	   
	   //searchInvoiceGridData(searchinvoicepoNumber, searchinvoiceAmount, searchinvoiceSubmitDt, searchinvoiceNumber, searchinvoicepaymentNumber,searchinvoiceVdrGSL);
   	var postData = JSON.stringify(searchitemdata);
   	console.log('resultData--filedSeletcedButtonID'+postData);

     if(searchinvoiceVdrGSL != '' || searchinvoicepoNumber !='' || searchinvoiceAmount !='' || searchinvoiceSubmitDt !='' || searchinvoiceNumber !='' || searchinvoicepaymentNumber !=''){

       $.ajax({

   	url: "https://scpcrpinvoicedetail-new.run.aws-usw02-pr.ice.predix.io/view/getInvoiceSearchWithFilter",

   	type: "post", //send it through post methodOfPayment

   	data : postData,

   	headers : {

   'Content-Type' : 'application/json'
    },
   success: function(responseData) {
       //  alert("search data available "+ JSON.stringify(responseData).length);

   console.log("response data with filter"+responseData);
   refreshInvoiceDataTable(responseData);
   },

   error: function ( xhr, status, error) {
    console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
    }
    });
   }
   else {
   $.ajax({
       url: "https://scpcrpinvoicedetail-new.run.aws-usw02-pr.ice.predix.io/view/getscpInvoiceearchWithOutFilter",
     type: "get", //send it through post methodOfPayment
      success: function(responseData) {

      //  alert("search data available "+ JSON.stringify(responseData).length);

       console.log(responseData);
       refreshInvoiceDataTable(responseData);
    },
     error: function ( xhr, status, error) {
         console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
       }
     });
   	}
    }
	
	function searchPaymentGridData(searchpaymentVdrGSL,searchpaymentpoNumber, searchpaymentamount, searchpaymentDate, searchpaymentinvoiceNumber, searchpaymentNumber){
    var searchitemdata = {poNumber:searchpaymentpoNumber, amount:searchpaymentamount, paymentDate:searchpaymentDate, invoiceNumber:searchpaymentinvoiceNumber, paymentNumber:searchpaymentNumber,venderGSl:searchpaymentVdrGSL};
	
	//searchinvoiceVdrGSL,searchpaymentpoNumber, searchpaymentamount, searchpaymentDate, searchpaymentinvoiceNumber, searchpaymentNumber
	var postData = JSON.stringify(searchitemdata);
	console.log('resultData--filedSeletcedButtonID'+postData);

  if(searchpaymentVdrGSL !='' || searchpaymentpoNumber !='' || searchpaymentamount !='' || searchpaymentDate !='' || searchpaymentinvoiceNumber !='' || searchpaymentNumber !=''){

    $.ajax({

	url: "https://scpcrpinvoicedetail-new.run.aws-usw02-pr.ice.predix.io/view/getscpPaymentsearchWithFilter",

	type: "post",

	data : postData,

	headers : {

'Content-Type' : 'application/json'
 },
success: function(responseData) {
    //  alert("search data available "+ JSON.stringify(responseData).length);

console.log("response data with filter"+responseData);
refreshPaymentDataTable(responseData);
},

error: function ( xhr, status, error) {
 console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
 }
 });
}
else {
$.ajax({
    url: "https://scpcrpinvoicedetail-new.run.aws-usw02-pr.ice.predix.io/view/getscpPaymentsearchWithOutFilter",
  type: "get", //send it through post methodOfPayment
   success: function(responseData) {

   //  alert("search data available "+ JSON.stringify(responseData).length);

    console.log(responseData);
    refreshPaymentDataTable(responseData);
 },
  error: function ( xhr, status, error) {
      console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
    }
  });
	}
 }
 
 });
 
 function refreshInvoiceDataTable(jsonData) {
           $('#invoicedataTable').dataTable().fnDestroy();
           loadInvoiceDataTable(jsonData);
    }
function loadInvoiceDataTable(jsonData){
     $('#invoicedataTable').dataTable({
     "aaData": jsonData,
                  dom: 'Bfrtip',
				  "bFilter" : false, 
				  "bPaginate": true,
				 "lengthMenu": [10, 25, 50, "All"],
                  buttons: ['excel' ],
                  "aoColumns": [
                       	{"mData": "invoiceNumber" },
                       { "mData": "invoiceDate" },
                       { "mData": "invoiceType" },
                       { "mData": "currency" },
                       { "mData": "amount" },
                       { "mData": "due" },
                       { "mData": "status" },
					   { "mData": "onHold" },
                       { "mData": "dueDate" },
                       { "mData": "poNumber" },
                       { "mData": "venderGSL" },
                       { "mData": "vendorName"}
               ],
			   "initComplete": function(settings){
					$('#invoicedataTable thead th').each(function () {
					   var $td = $(this);
					   $td.attr('title', $td.text());
					});

					/* Apply the tooltips */
					$('#invoicedataTable thead th[title]').tooltip(
					{
					   "container": 'body'
					});          
				} 

               }

);

$('#invoicedataTable_filter').addClass("pull-right");
$('#invoicedataTable_paginate').css({"font-size":"12px"});
$('#invoicedataTable_info').css({"font-size":"12px","font-weight": "bold"});
}



function refreshPaymentDataTable(jsonData) {
        $('#paymentdataTable').dataTable().fnDestroy();
        loadPaymentDataTable(jsonData);
      }

			  function loadPaymentDataTable(jsonData){
               $('#paymentdataTable').dataTable({
                            "aaData": jsonData,
                            dom: 'Bfrtip',
							"bFilter" : false, 
                            buttons: ['excel'],
                             "aoColumns": [
                                 { "mData": "paymentNumber" },
                                 { "mData": "amount" },
								 { "mData": "status" },
                                 { "mData": "currency" },
                                 { "mData": "invoiceNumber" },
                                 { "mData": "methodOfPayment" },
                                 { "mData": "paymentDate" },
                                 { "mData": "poNumber" },
                                 { "mData": "remitToSupplier" },
                                 { "mData": "remitToSupplierSite" },
                                 { "mData": "statusDate" },
								 { "mData": "venderGSl" },								 
								 { "mData": "vendorName" }

                             ], "initComplete": function(settings){
					$('#paymentdataTable thead th').each(function () {
					   var $td = $(this);
					   $td.attr('title', $td.text());
					});

					/* Apply the tooltips */
					$('#paymentdataTable thead th[title]').tooltip(
					{
					   "container": 'body'
					});          
				} 

                         }

				);

				$('#paymentdataTable_filter').addClass("pull-right");
				$('#paymentdataTable_paginate').css({"font-size":"12px"});
				$('#paymentdataTable_info').css({"font-size":"12px","font-weight": "bold"});
				
			  }

	function dateFormatt(Date) {
   
				//var s = '2016-04-30';
				var fields = Date.split("-");
			var yr = fields[0];
			var mon = fields[1];
			var Date = fields[2];
			var newYear=yr.substring(2,4 );
			var newDate;
			console.log('yr'+yr+mon+Date);
			var newMon=''
			if (mon=='01')
			newMon='Jan';			
			else if (mon=='02')
			newMon='Feb';
			else if (mon=='03')
			newMon='Mar';
			else if (mon=='04')
			newMon='Apr';
			else if (mon=='05')
			newMon='May';
			else if (mon=='06')
			newMon='Jun';
			else if (mon=='07')
			newMon='Jul';
			else if (mon=='08')
			newMon='Aug';
			else if (mon=='09')
			newMon='Sep';
			else if (mon=='10')
			newMon='Oct';
			else if (mon=='11')
			newMon='Nov';
			else if (mon=='12')
			newMon='Dec';

			newDate=Date+'-'+newMon+'-'+newYear;
			console.log('newDate'+newDate)
			return newDate;
}
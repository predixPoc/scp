'use strict';

app.factory('dueDeligence', ['$q', '$http','$rootScope','$cookies','$cookieStore','constants', 'toaster', '$filter',
	function ($q, $http,$rootScope,$cookies,$cookieStore,constants, toaster, $filter) {
	    var cookie = $cookieStore.get("sc_token");
		var refreshCookie = $cookieStore.get("sc_refresh_token");
		$cookieStore.put("companyAddress", []);
		var dueDeligence = {
			getCookieVal:function(){
				return $cookieStore.get("sc_token");
			},
		    setEntityVerification:function(obj, requestId){
		    	var url =constants.ENTITY_VERIFICATION.replace("#requestId#",requestId);					
				var d = $q.defer();	
				console.log(url);	
				var req = {
					headers: {
						'Content-Type': 'application/json',
						'Authorization' : dueDeligence.getCookieVal()
					},
					url: url,
					method: 'POST',	
					data:obj			

				};
				
				$http(req).then(function(reply) {							
						d.resolve(reply.data);
		        }, function(reply) {							
		            d.reject();
		        });
		        return d.promise;
		    },

		    getEntityVerificationSources:function(){
		    	var url =constants.ENTITY_VERIFICATION_SOURCES;	
				var d = $q.defer();
				console.log(url);
				var req = {
					headers: {
						'Content-Type': 'application/json',
						'Authorization' : dueDeligence.getCookieVal()
					},
					url: url,
					method: 'GET'
				};
				
				$http(req).then(function(reply) {							
						d.resolve(reply.data);
		        }, function(reply) {							
		            d.reject();
		        });
		        return d.promise;
		    },
		    getModeOfDelivery:function(){
		    	var url =constants.METHODS_OF_DELIVERY;	
				var d = $q.defer();
				console.log(url);
				var req = {
					headers: {
						'Content-Type': 'application/json',
						'Authorization' : dueDeligence.getCookieVal()
					},
					url: url,
					method: 'GET'
				};
				
				$http(req).then(function(reply) {							
						d.resolve(reply.data);
		        }, function(reply) {							
		            d.reject();
		        });
		        return d.promise;
		    },
		    getNegativeNewsCategories:function(){
		    	var url =constants.NEGATIVE_NEWS_CATEGORIES;	
				var d = $q.defer();
				console.log(url);
				var req = {
					headers: {
						'Content-Type': 'application/json',
						'Authorization' : dueDeligence.getCookieVal()
					},
					url: url,
					method: 'GET'
				};
				
				$http(req).then(function(reply) {							
						d.resolve(reply.data);
		        }, function(reply) {							
		            d.reject();
		        });
		        return d.promise;
		    },
		    setWatchlistScreening:function(obj, requestId){
		    	var url =constants.WATCHLIST_SCREENING.replace("#requestId#",requestId);					
				var d = $q.defer();	
				console.log(url);	
				var req = {
					headers: {
						'Content-Type': 'application/json',
						'Authorization' : dueDeligence.getCookieVal()
					},
					url: url,
					method: 'POST',	
					data:obj			

				};
				
				$http(req).then(function(reply) {							
						d.resolve(reply.data);
		        }, function(reply) {							
		            d.reject();
		        });
		        return d.promise;
		    },

		    setAdverseMediaResearch:function(obj, requestId){
		    	var url =constants.ADVERSE_MEDIA_RESEARCH.replace("#requestId#",requestId);					
				var d = $q.defer();	
				console.log(url);	
				var req = {
					headers: {
						'Content-Type': 'application/json',
						'Authorization' : dueDeligence.getCookieVal()
					},
					url: url,
					method: 'POST',	
					data:obj			

				};
				
				$http(req).then(function(reply) {							
						d.resolve(reply.data);
		        }, function(reply) {							
		            d.reject();
		        });
		        return d.promise;
		    },

		    setBankScreening:function(obj, requestId){
		    	var url =constants.BANK_SCREENING.replace("#requestId#",requestId);					
				var d = $q.defer();	
				console.log(url);	
				var req = {
					headers: {
						'Content-Type': 'application/json',
						'Authorization' : dueDeligence.getCookieVal()
					},
					url: url,
					method: 'POST',	
					data:obj			

				};
				
				$http(req).then(function(reply) {							
						d.resolve(reply.data);
		        }, function(reply) {							
		            d.reject();
		        });
		        return d.promise;
		    },

		    setOwnerOfficer:function(obj, requestId){
		    	var url =constants.OWNER_OFFICER.replace("#requestId#",requestId);					
				var d = $q.defer();	
				console.log(url);	
				var req = {
					headers: {
						'Content-Type': 'application/json',
						'Authorization' : dueDeligence.getCookieVal()
					},
					url: url,
					method: 'POST',	
					data:obj			

				};
				
				$http(req).then(function(reply) {							
						d.resolve(reply.data);
		        }, function(reply) {							
		            d.reject();
		        });
		        return d.promise;
		    },

		    setOwnerOfficerAdverseMedia:function(obj, requestId){
		    	var url =constants.OWNER_OFFICER_ADVERSE_MEDIA.replace("#requestId#",requestId);					
				var d = $q.defer();	
				console.log(url);	
				var req = {
					headers: {
						'Content-Type': 'application/json',
						'Authorization' : dueDeligence.getCookieVal()
					},
					url: url,
					method: 'POST',	
					data:obj			

				};
				
				$http(req).then(function(reply) {							
						d.resolve(reply.data);
		        }, function(reply) {							
		            d.reject();
		        });
		        return d.promise;
		    },

		    setSpiritLetter:function(obj, requestId){
		    	var url =constants.SPIRIT_LETTER.replace("#requestId#",requestId);					
				var d = $q.defer();	
				console.log(url);	
				var req = {
					headers: {
						'Content-Type': 'application/json',
						'Authorization' : dueDeligence.getCookieVal()
					},
					url: url,
					method: 'POST',	
					data:obj			

				};
				
				$http(req).then(function(reply) {							
						d.resolve(reply.data);
		        }, function(reply) {							
		            d.reject();
		        });
		        return d.promise;
		    },

		    setReference:function(obj, requestId){
		    	var url =constants.REFERENCE.replace("#requestId#",requestId);					
				var d = $q.defer();	
				console.log(url);	
				var req = {
					headers: {
						'Content-Type': 'application/json',
						'Authorization' : dueDeligence.getCookieVal()
					},
					url: url,
					method: 'POST',	
					data:obj			

				};
				
				$http(req).then(function(reply) {							
						d.resolve(reply.data);
		        }, function(reply) {							
		            d.reject();
		        });
		        return d.promise;
		    },

		    setAccountFlag:function(obj, requestId){
		    	var url =constants.ACCOUNT_FLAG.replace("#requestId#",requestId);					
				var d = $q.defer();	
				console.log(url);	
				var req = {
					headers: {
						'Content-Type': 'application/json',
						'Authorization' : dueDeligence.getCookieVal()
					},
					url: url,
					method: 'POST',	
					data:obj			

				};
				
				$http(req).then(function(reply) {							
						d.resolve(reply.data);
		        }, function(reply) {							
		            d.reject();
		        });
		        return d.promise;
		    },

			getTaskLists:function(id){
		    	var url =constants.LIST_TASKS;	
				var d = $q.defer();
				console.log(url);
				var req = {
					headers: {
						'Content-Type': 'application/json',
						'Authorization' : dueDeligence.getCookieVal()
					},
					url: url,
					method: 'GET'
				};
				
				$http(req).then(function(reply) {							
						d.resolve(reply.data);
		        }, function(reply) {							
		            d.reject();
		        });
		        return d.promise;
		    },
			 getTaskListsNew:function(size, start){
				var data = {
					"token": dueDeligence.getCookieVal()
				};

		    	var url =constants.LIST_TASKS_NEW+"?start="+start;					
				var d = $q.defer();
				console.log(url);
				var req = {
					headers: {
						'Content-Type': 'application/json',
						'Authorization' : dueDeligence.getCookieVal()
					},
					url: url,
					method: 'POST',
					data:data
				};
				
				$http(req).then(function(reply) {							
						d.resolve(reply.data);
		        }, function(reply) {							
		            d.reject();
		        });
		        return d.promise;
		    },
			 entityRule:function(obj){
		    	var url =constants.ENTITY_RULE;					
				var d = $q.defer();						
				var req = {
					headers: {
						'Content-Type': 'application/json',
						'Authorization' : dueDeligence.getCookieVal()
					},
					url: url,
					method: 'POST',	
					data:obj			

				};
				
				$http(req).then(function(reply) {							
						d.resolve(reply.data);
		        }, function(reply) {							
		            d.reject();
		        });
		        return d.promise;
		    },
		    runWatchlist:function(obj){
		    	var url =constants.RUN_WATCHLIST;					
				var d = $q.defer();						
				var req = {
					headers: {
						'Content-Type': 'application/json',
						'Authorization' : dueDeligence.getCookieVal()
					},
					url: url,
					method: 'POST',	
					data:obj			

				};
				
				$http(req).then(function(reply) {							
						d.resolve(reply.data);
		        }, function(reply) {							
		            d.reject();
		        });
		        return d.promise;
		    },
		    getCheckMode:function(obj){
		    	var url =constants.GET_CHECKMODE;					
				var d = $q.defer();						
				var req = {
					headers: {
						'Content-Type': 'application/json',
						'Authorization' : dueDeligence.getCookieVal()
					},
					url: url,
					method: 'POST',	
					data:obj			

				};
				
				$http(req).then(function(reply) {							
						d.resolve(reply.data);
		        }, function(reply) {							
		            d.reject();
		        });
		        return d.promise;
		    },
			getFileLists:function(supplierId, docType, flag){
		    	var url =constants.FILE_MULTIPLE_LIST+'?SUPPLIERID='+supplierId+'&docType='+docType+'&flag='+flag;	
				var d = $q.defer();
				console.log(url);
				var req = {
					headers: {
						'Content-Type': 'application/json',
						'Authorization' : dueDeligence.getCookieVal()
					},
					url: url,
					method: 'GET'
				};
				
				$http(req).then(function(reply) {							
						d.resolve(reply.data);
		        }, function(reply) {							
		            d.reject();
		        });
		        return d.promise;
		    },
			getFileInfo:function(supplierId, fileId, docType){
		    	var url =constants.FILE_LIST+supplierId+'-'+fileId+'-'+docType;	
				var d = $q.defer();
				console.log(url);
				var req = {
					headers: {
						'Content-Type': 'application/json',
						'Authorization' : dueDeligence.getCookieVal()
					},
					url: url,
					cache: true,
					method: 'GET'
				};
				
				$http(req).then(function(reply) {							
						d.resolve(reply.data);
		        }, function(reply) {							
		            d.reject();
		        });
		        return d.promise;
		    },
		    getTags:function(){
		    	var url =constants.TAGS;
				var d = $q.defer();
				var req = {
					headers: {
						'Content-Type': 'application/json',
						'Authorization' : dueDeligence.getCookieVal()
					},
					url: url,
					method: 'GET'
				};
				$http(req).then(function(reply) {
			     d.resolve(reply.data);
		        }, function(reply) {
		            d.reject();
		        });
		        return d.promise;
		    },
		    setTags:function(obj){
		    	var url =constants.TAGS;
				var d = $q.defer();
				var req = {
					headers: {
						'Content-Type': 'application/json',
						'Authorization' : dueDeligence.getCookieVal()
					},
					url: url,
					method: 'PUT',
					data: obj
				};
				$http(req).then(function(reply) {
			     d.resolve(reply.data);
		        }, function(reply) {
		            d.reject();
		        });
		        return d.promise;
		    }

		}
		return dueDeligence;
	}
]);

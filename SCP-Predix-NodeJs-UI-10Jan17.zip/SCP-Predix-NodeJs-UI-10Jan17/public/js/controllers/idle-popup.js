/*--- idle pop-up code ---*/

app.controller('idlePopupCtrl', function(supplier,$scope,$interval,$cookieStore) {
	$scope.idlebutton = function(){
			//alert("test");
		supplier.getToken().then(function(d) {
		$scope.data = d;
				$cookieStore.put("sc_token","bearer "+d.access_token);
				$cookieStore.put("sc_refresh_token", d.refresh_token);
		});		
	}
	 
	 	 // popup timer
	//$(document).ready(function(){
	//var idleTime = 0;
	var timoutWarning = 1080000; //show warning popup timer 18 min
	var timoutNow = 1200000; // show timeout in 20min
	var updateTime; // for timer
	var timeSec; // for timer
	var idleInterval; //  settimout function for warning pop-up 18 min
	var timeoutTimer; //  settimout function for timeout pop-up 20 min
	
	function idlelogout() {		
		//alert("timeout111");
		//location.href = 'index.html';
		//logout();
		document.cookie = encodeURIComponent("sc_sso") + "=deleted; expires=" + new Date(0).toUTCString();
		document.cookie = encodeURIComponent("sc_token") + "=deleted; expires=" + new Date(0).toUTCString();
		
		var fullUrl = window.location.href;
		var extractUrl = fullUrl.split('//');
		var extractUrl1=extractUrl[1];
		var extractUrl2 = extractUrl1.split('/')
		var finalUrl = extractUrl2[0]+"/logout"; 
		var logoutUrl = finalUrl; 
		window.location.replace("https://"+finalUrl);	
	}
	function init() {
		//var timeSec = (30000 + 60000) / 1000;
		timeSec = 120 ;
		updateTime = setInterval(function(){
			if(timeSec >= 0)
			{
				$('.CountDown').html("0:"+(timeSec));
				console.log(timeSec);
				timeSec--;
			}		  
		},1000);
	}
	function StartWarningTimer() {
		idleInterval = setTimeout(timerIncrement, timoutWarning);
		timeoutTimer = setTimeout(idlelogout, timoutNow);
	}
	StartWarningTimer();	
    $(".containermain").mousemove(function (e) {
		clearTimeout(idleInterval);
		clearTimeout(timeoutTimer);
		clearInterval(updateTime);
		timeSec = 120;
		StartWarningTimer();
      //  idleTime = 0;
    });	
	var keypressYes = setInterval(timoutNow);
    $(".containermain").keypress(function (e) { 
		clearTimeout(idleInterval);
		clearTimeout(timeoutTimer);
		clearInterval(updateTime);
		timeSec = 120;
		StartWarningTimer();
       // idleTime = 0;
		//clearInterval(keypressYes);
    });
 		
    $(".sleepy-close, .sleepy-overlay, .sleepy-wake-up, .idleyes-btn").click(function () {
        $(".sleepy-overlay").hide();
       // idleTime = 0;
    });
    $('.sleepy-modal').click(function (event) {
        event.stopPropagation();
    });
	function timerIncrement() {
	   // idleTime = idleTime + 1;
	  //  if (idleTime > 1) {
			$('.sleepy-overlay').fadeIn('slow');
			init();
			//idleTime = 0;
			//var idleYes = setInterval(idlelogout, timoutWarning);
			//clearinterval when popup show 
			$(".idleyes-btn").click(function () {
				$(".sleepy-overlay").hide();
				//idleTime = 0;
				//clearInterval(idleYes);
				clearTimeout(idleInterval);
				clearTimeout(timeoutTimer);
				clearInterval(updateTime);
				timeSec = 120;
				StartWarningTimer();
			});	
	   // }
	}
	//refresh token in 20 min
		  $interval(callAtTimeout, 1200000);
			function callAtTimeout() 
		{
			//alert("refresh token");
			$(".idleyes-btn").click(function () {
			clearInterval(callAtTimeout);
			});
				supplier.getToken().then(function(d) {				
					$scope.data = d;
						$cookieStore.put("sc_token","bearer "+d.access_token);
						$cookieStore.put("sc_refresh_token", d.refresh_token);

				});
				 console.log(".data");
		} 
		// logout code
	$scope.logout = function(){
		//alert('hi');
		document.cookie = encodeURIComponent("sc_sso") + "=deleted; expires=" + new Date(0).toUTCString();
		document.cookie = encodeURIComponent("sc_token") + "=deleted; expires=" + new Date(0).toUTCString();
		
		var fullUrl = window.location.href;
		var extractUrl = fullUrl.split('//');
		var extractUrl1=extractUrl[1];
		var extractUrl2 = extractUrl1.split('/')
		var finalUrl = extractUrl2[0]+"/logout"; 
		var logoutUrl = finalUrl; 
		window.location.replace("https://"+finalUrl);
		//$("#logout").attr("href", logoutUrl); 
	}

	
});
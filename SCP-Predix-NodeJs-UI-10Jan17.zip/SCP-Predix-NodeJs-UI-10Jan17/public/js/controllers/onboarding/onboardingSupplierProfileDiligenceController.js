app.controller('onboardingSupplierProfileDiligenceController', function ($scope, $filter, $http, $rootScope, constants,
        $state, Auth, $timeout, toaster, $cookies, $cookieStore, $sce, WorkFlow, supplier) {

    var cookie = $cookieStore.get("sc_token");
    var requestId = $cookieStore.get("requestId");
    var requestIdString = requestId.toString();
    // var persona = $cookieStore.get("Persona");
    $scope.supplier = {};
    $scope.supplierInfo = {};

    if (!WorkFlow.getRequestId()) {
        toaster.pop('error', "No Open Task found !", "Request Id is retrieving as null");
        //	$state.go('supplierHome');
        return;
    }


    // Back Button Click
    $scope.prevFromDiligence = function () {
        $state.go('supplierProfileDiversity')
    }
    var changeQuestions = function () {
        Auth.getRoles().then(function (roles) {
            if (Auth.isSupplierRole(roles.roles)) {
                $scope.showSupplierQuestion = true;
                $scope.loader = false;
            } else {
                $scope.showSupplierQuestion = false;
                $scope.loader = false;
            }
        }, function (data) {
            $scope.loader = false;
        });
    }
    changeQuestions();
    // Get Country List
    supplier.getCountryList().then(function (data) {
        $scope.chooseCountries = data;
    }, function () {
        toaster.pop('error', "Country list", "server not responding");
    });

    // Get Phone Codes
    supplier.getPhoneCodes().then(function (data) {
        $scope.phoneCodes = data;
    }, function () {
        toaster.pop('error', "Phone list", "server not responding");
    });

    // get ndaData 
    var getNdaData = function () {
        $scope.addresses = {};
        var addresses = (WfModel.supplier.addresses) ? (WfModel.supplier.addresses) : null;
        angular.forEach(addresses, function (address, index) {
            if (address.addressTypes.indexOf("LEGAL") != -1) {
                if (!$scope.addresses.legalentity) {
                    $scope.addresses.legalentity = [];
                }
                $scope.addresses.legalentity.push(address.location);
            }
        });
        if ($scope.addresses.legalentity[0].countryId) {
            supplier.getCountryById($scope.addresses.legalentity[0].countryId).then(function (data) {
                $scope.isoA3 = data.isoA3;
                if (WfModel.subscription.businessLevels[1]) {
                    supplier.getbusinessLevelsNameFromID(WfModel.subscription.businessLevels[1]).then(function (data) {
                        $scope.businessLevel2Name = data.name;

                        // Get NDA Data
                        var legalAddress = $scope.addresses.legalentity[0].addressLine1 + "," + $scope.addresses.legalentity[0].cityName + "," + $scope.isoA3 + "," + $scope.addresses.legalentity[0].postalCode;
                        var ndaObj = {
                            "placeHolderValues": {
                                "legalName": WfModel.supplier.legalName,
                                "legalAddress": legalAddress,
                                "businessLevel2": $scope.businessLevel2Name,
                                "geEntityAddress": "4636 Somerton Rd, Feasterville-Trevose, PA 19053",
                            }
                        }
                        supplier.getNdaData(ndaObj).then(function (response) {
                            $scope.ndaContent = $sce.trustAsHtml(response.content);
                        }, function (data) {

                        });
                    }, function (data) {

                    });
                }
            }, function () {

            });

        }
    }
    // Save Button Click
    $scope.saveAndNext = function (supplierInfo, form, redirect) {
        $scope.submitted = true;
        $scope.loader = true;
        var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        if (supplierInfo.isSupplierTTTGProvider == true || supplierInfo.isSupplierTTTGProductProvider == true) {
            if (supplierInfo.TTTGProviderContactEmail == "" || supplierInfo.TTTGProviderContactEmail == undefined) {
                toaster.pop('error', "Provide the e-mail", "Please answer all the mandatory question");
                return;
            }
            if (!re.test(supplierInfo.TTTGProviderContactEmail)) {
                toaster.pop('error', "Email", "Email validation is incorrect");
                return;
            }
        }

        if ($scope.diligenceRules.commercialReferences.enabled && $scope.diligenceRules.commercialReferences.mandatory) {
            if ($scope.supplier.commercialReferences == undefined) {
                toaster.pop('error', "Add Commercial Reference", "Please Add Commercial Reference");
                return;
            } else if ($scope.supplier.commercialReferences.length < 2) {
                toaster.pop('error', "Two Commercial Reference Required", "Please provide two commercial references");
                return;
            }
        }
//        if (supplierInfo.settlementProcessId == null && $scope.paymentTermsRuleData.settlementProcessId.mandatory == true && $scope.paymentTermsRuleData.settlementProcessId.enabled == true) {
//            toaster.pop('error', "Settlement Process Id", "Please answer all the mandatory question");
//            return;
//        }
        if ($scope.diligenceRules.isSupplierTTTGProductProvider.enabled && $scope.diligenceRules.isSupplierTTTGProductProvider.mandatory && supplierInfo.isSupplierTTTGProductProvider == null) {
            toaster.pop('error', "TTTG Product Provider", "Please answer all the mandatory question");
            return;
        }
        if ($scope.diligenceRules.isSupplierTTTGProvider.enabled && $scope.diligenceRules.isSupplierTTTGProvider.mandatory && supplierInfo.isSupplierTTTGProvider == null) {
            toaster.pop('error', "TTTG Provider", "Please answer all the mandatory question");
            return;
        }
        if ($scope.diligenceRules.isLaborBroker.enabled && $scope.diligenceRules.isLaborBroker.mandatory && supplierInfo.isLaborBroker == null) {
            toaster.pop('error', "Labor Broker", "Please answer all the mandatory question");
            return;
        }
        if ($scope.diligenceRules.onboardingSupplierRedFlag.enabled && $scope.diligenceRules.onboardingSupplierRedFlag.mandatory && supplierInfo.onboardingSupplierRedFlag == null) {
            toaster.pop('error', "Supplier Red Flag", "Please answer all the mandatory question");
            return;
        }
        if ($scope.diligenceRules.isSupplierHasComplianceProgram.enabled && $scope.diligenceRules.isSupplierHasComplianceProgram.mandatory && supplierInfo.isSupplierHasComplianceProgram == null) {
            toaster.pop('error', "Supplier has complaince program", "Please answer all the mandatory question");
            return;
        }
        var commercialReferencesErrorFlag = false;
        angular.forEach($scope.supplier.commercialReferences, function (contact) {
            if ($scope.diligenceRules.commercialReferencesCompanyName.enabled && $scope.diligenceRules.commercialReferencesCompanyName.mandatory && contact.companyName == null) {
                commercialReferencesErrorFlag = true;
//                toaster.pop('error', "Company Name", "Please answer all the mandatory question");
//                return;
            }
            if ($scope.diligenceRules.commercialReferencesContactFirstName.enabled && $scope.diligenceRules.commercialReferencesContactFirstName.mandatory && contact.contactFirstName == null) {
                commercialReferencesErrorFlag = true;
//                toaster.pop('error', "Commercial References Contact First Name", "Please answer all the mandatory question");
//                return;
            }
            if ($scope.diligenceRules.commercialReferencesContactLastName.enabled && $scope.diligenceRules.commercialReferencesContactLastName.mandatory && contact.contactLastName == null) {
                commercialReferencesErrorFlag = true;
//                toaster.pop('error', "Commercial References Contact last Name", "Please answer all the mandatory question");
//                return;
            }
            if ($scope.diligenceRules.commercialReferencesContactEmail.enabled && $scope.diligenceRules.commercialReferencesContactEmail.mandatory && contact.contactEmail == null) {
                commercialReferencesErrorFlag = true;
//                toaster.pop('error', "Commercial References Contact Email", "Please answer all the mandatory question");
//                return;
            }
            if ($scope.diligenceRules.commercialReferencesContactPhone.enabled && $scope.diligenceRules.commercialReferencesContactPhone.mandatory && contact.contactPhone == null) {
                commercialReferencesErrorFlag = true;

            }
        });
        if (commercialReferencesErrorFlag == true) {
            toaster.pop('error', "Commercial References", "Please answer all the mandatory question");
            return;
        }
        if ($scope.diligenceRules.ndaAccepted.enabled && $scope.diligenceRules.ndaAccepted.mandatory && supplierInfo.ndaAccepted == null) {
            toaster.pop('error', "NDA Accepted Option", "Please answer all the mandatory question");
            return;
        }
        WfModel.dueDiligence = (WfModel.dueDiligence == null) ? {} : WfModel.dueDiligence;

        WfModel.dueDiligence.isTTTGProductProvider = supplierInfo.isSupplierTTTGProductProvider;
        WfModel.dueDiligence.tttgproviderContactEmail = supplierInfo.TTTGProviderContactEmail;
        WfModel.dueDiligence.isTTTGProvider = supplierInfo.isSupplierTTTGProvider;
        WfModel.dueDiligence.isLaborBroker = supplierInfo.isLaborBroker;
        WfModel.dueDiligence.laborBrokerCountries = supplierInfo.laborBrokerCountries;
        WfModel.dueDiligence.previousCompanyNames = supplierInfo.previousCompanyNames;
        WfModel.dueDiligence.onboardingSupplierRedFlag = supplierInfo.onboardingSupplierRedFlag;
        WfModel.dueDiligence.onboardingSupplierRedFlagComment = supplierInfo.onboardingSupplierRedFlagComment;
        WfModel.dueDiligence.isSupplierHasComplianceProgram = supplierInfo.isSupplierHasComplianceProgram;
        WfModel.dueDiligence.isSupplierHasComplianceProgramWithInproperPayment = supplierInfo.isSupplierHasComplianceProgramWithInproperPayment;
        WfModel.dueDiligence.commercialReferences = $scope.supplier.commercialReferences;
        WfModel.dueDiligence.ndaAccepted = supplierInfo.ndaAccepted;
        WfModel.dueDiligence.ndaDocumentId = $scope.ndaDocumentId;
        WorkFlow.setVariablesV2(WfModel).then(function (data) {
            $scope.loader = false;
            $rootScope.supplierProfileDueDiligenceDone = true;
            toaster.pop('success', "Saved successfully");
            if (redirect) {
                $state.go('supplierReview');
            }

        }, function (data) {
            $scope.loader = false;
            toaster.pop('error', "Workflow Api failed");
        });
    }

    $scope.addContact = function () {
        if (!$scope.supplier.commercialReferences) {
            $scope.supplier.commercialReferences = [];
        }
        $scope.supplier.commercialReferences.push({});
    }

    $scope.deleteContact = function (contact) {
        var index = $scope.supplier.commercialReferences.indexOf(contact);
        $scope.supplier.commercialReferences.splice(index, 1);
        if ($scope.supplier.commercialReferences.length < 1) {
            $scope.supplierInfo.orderFulfilmentAddress = undefined;
        }
    }

    // Initialize
    var WfModel = {};
    // Get Compliance Form Conditions
    supplier.getDiligenceRules(requestIdString).then(function (response) {
        $scope.loader = true;
        $scope.skipCompliance = true;
        if (response.data) {
            $scope.diligenceRules = response.data;
            angular.forEach($scope.diligenceRules, function (value, key) {
                if (value.enabled == true) {
                    $scope.skipCompliance = false;
                    return;
                }
            })
            if ($scope.skipCompliance == true) {
                $rootScope.supplierProfileDueDiligenceDone = true;
                $state.go('supplierReview');
            }
        }

        // Get WorkFlow Model
        WorkFlow.getVariablesV2().then(function (workflowData) {
            WfModel = workflowData.data;
            if (workflowData.data) {
                getNdaData();
                $scope.supplierInfo.ndaAccepted = WfModel.dueDiligence.ndaAccepted;
                $scope.supplierInfo.isSupplierTTTGProvider = WfModel.dueDiligence.isTTTGProvider;
                $scope.supplierInfo.isSupplierTTTGProductProvider = WfModel.dueDiligence.isTTTGProductProvider;
                $scope.supplierInfo.TTTGProviderContactEmail = WfModel.dueDiligence.tttgproviderContactEmail;
                $scope.supplierInfo.isLaborBroker = WfModel.dueDiligence.isLaborBroker;
                var selectedLaborBrokerCountries = [];
                angular.forEach(WfModel.dueDiligence.laborBrokerCountries, function (value) {
                    var selectedCountries = parseInt(value);
                    selectedLaborBrokerCountries.push(selectedCountries);
                })
                $scope.supplierInfo.laborBrokerCountries = selectedLaborBrokerCountries;
                $scope.supplierInfo.previousCompanyNames = WfModel.dueDiligence.previousCompanyNames;
                $scope.supplierInfo.onboardingSupplierRedFlag = WfModel.dueDiligence.onboardingSupplierRedFlag;
                $scope.supplierInfo.onboardingSupplierRedFlagComment = WfModel.dueDiligence.onboardingSupplierRedFlagComment;
                $scope.supplierInfo.isSupplierHasComplianceProgram = WfModel.dueDiligence.isSupplierHasComplianceProgram;
                $scope.supplierInfo.isSupplierHasComplianceProgramWithInproperPayment = WfModel.dueDiligence.isSupplierHasComplianceProgramWithInproperPayment;
                if(WfModel.dueDiligence.commercialReferences.length > 0){
                    $scope.supplier.commercialReferences = WfModel.dueDiligence.commercialReferences;
                }
                if (workflowData.data.dueDiligence.ndaDocumentId) {
                    $scope.ndaDocumentId = WfModel.dueDiligence.ndaDocumentId;
                    $scope.fileDownload_ndaDocument = true;
                    var getId = document.getElementById('downloadUrlForFile_ndaDocument');
                    getId.href = constants.FILE_DOWNLOAD + WfModel.dueDiligence.ndaDocumentId;
                    supplier.getlistFileUploaded($scope.ndaDocumentId).then(function (data) {
                        $scope.fileNameNdaDocument = data.FileName;
                    }, function (data) {
                        $scope.loader = false;
                    });
                }

            } else {
                $scope.supplier = [];
                $scope.supplier.commercialReferences = [{}];
                $scope.loader = false;
            }
            $scope.loader = false;
        }, function () {
            $scope.loader = false;
            toaster.pop('error', 'Workflow API', "Server not responding");
        });
    });

    //file upload and drag+drop
    $scope.eventId = "";
    $scope.getCurrentIdFound = "";
    var eventIdTrack;
    var currentId;

    //set the files
    $scope.setFiles = function (element) {
        var getElementId = element.id.split('_');
        $scope.eventId = getElementId[1];
        $scope.$apply(function ($scope) {
            $scope.files = []
            for (var i = 0; i < element.files.length; i++) {
                $scope.files.push(element.files[i]);
                uploadFileSend($scope.files[0])
            }
        });
    };

    //upload the file
    function uploadFileSend(file) {
        $scope.loader = true;
        console.log("supplierApiUrl", constants.SUPPLIER_API_URL);
        console.log("file", file);
        $($scope.getCurrentIdFound).css("background-color", "#eaf1f8");
        $scope.preloader = true;
        $scope.fileName = file.name;
        var formData = new FormData();
        formData.append('file', file);
        formData.append('SUPPLIERID', localStorage.getItem("userId"));
        console.log("formData", formData)
        var req = {
            method: 'POST',
            url: constants.FILE_UPLOAD + $scope.eventId,
            transformRequest: angular.identity,
            headers: {
                'Content-Type': undefined,
                'Authorization': WorkFlow.getCookieVal()
            },
            data: formData,
            cache: false,
            contentType: false,
            processData: false
        };
        $http(req).then(function (data) {
            var divAttribute;
            var downloadUrl;
            var userId = localStorage.getItem("userId");
            $scope.getCurrentIdFound = "";
            $scope.eventId = "";
            $scope.preloader = false;
            var pJson = data.data;
            var finalUrlData = pJson.key;
            var dataFile = finalUrlData.split(':');
            var docName = data.data.docType;
            var specificFileName = dataFile[3];
            $scope.loader = false;
            toaster.pop('success', "Document Upload", "Document had been uploaded successfully");
            if (dataFile[1] == "ndaDocument") {
                $scope.fileDownload_ndaDocument = true;
                $scope.fileNameNdaDocument = dataFile[3];
                downloadUrl = data.data.filePath;
                $scope.ndaDocumentName = $scope.fileNameNdaDocument;
                $scope.ndaDocumentPath = downloadUrl.split('/');
                $scope.ndaDocumentId = downloadUrl.split('/')[$scope.ndaDocumentPath.length - 2];
                divAttribute = document.getElementById('downloadUrlForFile_ndaDocument');
                divAttribute.href = '/pc_document_management' + downloadUrl;

            }
        }, function () {
            $scope.loader = false;
            $scope.eventId = "";
            $scope.getCurrentIdFound = "";
            $scope.preloader = false;
            toaster.pop('error', "Document Upload", "server not responding");
        });
    }
});

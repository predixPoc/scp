app.controller('supplierDashboardController', function($scope, $filter, $http, $rootScope,constants,
		$state, Auth, $timeout, toaster, $cookies, $cookieStore, WorkFlow, supplier) {
	Auth.getRoles().then(function(roles){
	    // if (Auth.isRoleExists(roles.authorities , 'ADD_SUPPLIER')){
		   //  	//$scope.inviteEnabled = true;
	    // 	$cookieStore.put("Persona","Sourcing");
	    // }else{
	    // 	$cookieStore.put("Persona","Supplier");
	    // }
	    $cookieStore.put("Persona",roles.roles[0].name);
		$cookieStore.put("uId", roles.id);
	}, function() {
		toaster.pop('error', "Role list", "server not responding");
	});	
	
/* 	$scope.start = function (){	
	
	  	 WorkFlow.getAvailableTask().then(function(data) {	  	
	  			WorkFlow.setTask(data.data[0].id);	
	  			WorkFlow.setInstance(data.data[0].processInstanceId);	    		 	    	
	    	}, function(data) {
	    		toaster.pop('error', "getAvailableTask API Failed");
	      	}); 
	
		$state.go('supplierProfileCompany');		
	} */

});
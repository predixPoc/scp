app.controller('onboardingSupplierProfileCompanyController', function ($scope, $filter, $http, $rootScope, constants,
        $state, Auth, $timeout, toaster, $cookies, $cookieStore, WorkFlow, supplier) {
    $scope.vatAddedTrue = false;
    $scope.supplierInfo = {};
    $scope.addNewData = {}
    $scope.goodtypeData = true;
    $scope.disregardMain = false;
    $scope.disRegardSection = false;
    $scope.supplierInfo.exemptCheckBox = 0;
    $scope.supplierInfo.exemptCheckBox = false;
    $scope.vatlist = [];
    $scope.taxTable = [];
    $scope.crossBorder = false;
    $scope.change = false;
    $rootScope.disRegardSection = false;
    $rootScope.exemptCheckBox = false;
    $scope.fileDownload_CrossDownload = false;
    $scope.loader = true;

    var allData;
    var WfModel = {};
    supplier.getCountryList().then(function (data) {
        $scope.chooseCountries = data;
    }, function () {
        toaster.pop('error', "Country list", "server not responding");
    });

    $scope.loader = true;
    WorkFlow.getAvailableTask().then(function (data) {
        $scope.loader = true;
        if (data.data.length > 0) {

            WorkFlow.setTask(data.data[0].id);
            //WorkFlow.setRequestId(data.data[0].id);   
            WorkFlow.setInstance(data.data[0].processInstanceId);


            WorkFlow.getVRequestIdV2().then(function (data1) {
                $scope.loader = true;
                var requestObj = (data1.data[0]) ? WorkFlow.makeModel(data1.data[0].variables) : {};
                //console.log("MIDHUN",requestObj.requestId);
                if (requestObj.requestId) {

                    WorkFlow.setRequestId(requestObj.requestId);
                } else {
                    toaster.pop('error', "No Open Task found !", "Request Id is retrieving as null");
                    //$state.go('supplierHome');
                    return
                }
                ;

                if (WorkFlow.getInstance()) {
                    WorkFlow.getVariablesV2().then(function (workflowData) {
                        $scope.loader = true;
                        $scope.change = false;
                        $scope.mainTaxNo = '';
                        WfModel = workflowData.data;
                        if (workflowData.data.supplier != null && workflowData.data.supplier.legalTax != null) {
                            if (workflowData.data.supplier.legalTax.taxClassificationId != "" || workflowData.data.supplier.legalTax.taxClassificationId != undefined) {
                                $rootScope.taxClassifyValidation = workflowData.data.supplier.legalTax.taxClassificationId;
                                angular.forEach($rootScope.withHoldingTypesOld, function (item, index) {
                                    if (workflowData.data.supplier.legalTax.taxClassificationId == item.id) {
                                        $scope.taxClassifyValidationBackUp = item.name;
                                    }
                                });
                            }
                        }
                        $rootScope.erpId = (WfModel.subscription.erpId) ? WfModel.subscription.erpId : null;


                        ////////////////MAIN FUNCTION///////////////////////////////////////
                        if (workflowData.data.supplier) {
                            if (workflowData.data.supplier.legalTax == null || workflowData.data.supplier.legalTax == undefined || workflowData.data.supplier.legalTax == '') {
                                $rootScope.countryFinal = (workflowData.data.supplier) ? workflowData.data.supplier.countryId : ''
//                             var ruleObj = {
//                                 "request": {
//                                     "countryId": $rootScope.countryFinal,
//                                     "taxClassificationId": $scope.taxClassifyValidationBackUp,
//                                     "exemptFromWithholdingTax": workflowData.data.supplier.legalTax.exemptFromWithholdingTax,
//                                     "isDisregardedEntityForUS": workflowData.data.supplier.legalTax.isDisregardedEntityForUS,
//                                     "erpIds": (WfModel.subscription) ? WfModel.subscription.erpId : [],
//                                     "crossBorderTaxes": [{
//                                         "id": 123,
//                                         "exemptFromWithholdingTax": (workflowData.data.supplier.crossBorderTax[0]) ? workflowData.data.supplier.crossBorderTax[0].exemptFromWithholdingTax : null,
//                                         "providedProductId": (workflowData.data.supplier.crossBorderTax[0]) ? workflowData.data.supplier.crossBorderTax[0].providedProductId : null
//                                     }]
//                                 }
//
//                             };	 
                            } else {
                                $rootScope.countryFinal = (workflowData.data.supplier.legalTax) ? workflowData.data.supplier.legalTax.countryId : null;
//                         var ruleObj = {
//                                 "request": {
//                                     "countryId": $rootScope.countryFinal,
//                                     "taxClassificationId": $scope.taxClassifyValidationBackUp,
//                                     "exemptFromWithholdingTax": workflowData.data.supplier.legalTax.exemptFromWithholdingTax,
//                                     "isDisregardedEntityForUS": workflowData.data.supplier.legalTax.isDisregardedEntityForUS,
//                                     "erpIds": (WfModel.subscription) ? WfModel.subscription.erpId : [],
//                                     "crossBorderTaxes": [{
//                                         "id": 123,
//                                         "exemptFromWithholdingTax": (workflowData.data.supplier.crossBorderTax[0]) ? workflowData.data.supplier.crossBorderTax[0].exemptFromWithholdingTax : null,
//                                         "providedProductId": (workflowData.data.supplier.crossBorderTax[0]) ? workflowData.data.supplier.crossBorderTax[0].providedProductId : null
//                                     }]
//                                 }
//
//                             };
                            }
                            $scope.loader = true;
//                     if(ruleObj){
//                     	$scope.loader=true;
//                     supplier.getCompanyPageUiVisibility(ruleObj).then(function(data) {
//                    	 $scope.loader=true;
//                         $scope.dataUIVisibility = data.data;
//                         if ($scope.dataUIVisibility.crossBorderTax[0].documentId.enabled == true) {
//                             $scope.headText = "Document"
//                         }
//                         if ($scope.dataUIVisibility.crossBorderTax[0].exemptDocumentId.enabled == true) {
//                             $scope.headText = "Exempt Document"
//                         }
//                         if ($scope.dataUIVisibility.crossBorderTax[0].w8DocId.enabled == true) {
//                             $scope.headText = "w8 Document"
//                         }
//                         if ($scope.dataUIVisibility.crossBorderTax[0].w8BenDocId.enabled == true) {
//                             $scope.headText = "W8 Ben Document"
//                         }
//                         if ($scope.dataUIVisibility.crossBorderTax[0].form8233DocId.enabled == true) {
//                             $scope.headText = "Form 8233 Document"
//                         }
//                         
//                     }, function(data) {
//                     	$scope.loader=false;
//                     });
//                 }

                        }

                        ////////////////////////////////////////////////////////////////////////    
                        $scope.loader = true;
                        $scope.addNewData.name = (workflowData.data.supplier) ? workflowData.data.supplier.legalName : '';
                        $scope.supplierInfo.legalLanguagename = (workflowData.data.supplier) ? workflowData.data.supplier.legalName : '';
                        if (workflowData.data.supplier) {
                            if (WfModel.supplier.alternateId) {
                                $scope.supplierInfo.dbaName = (workflowData.data.supplier.alternateId[0]) ? workflowData.data.supplier.alternateId[0].value : null;
                            }

                            if (workflowData.data.supplier.legalNameLocal) {
                                $scope.supplierInfo.legalLanguagename = workflowData.data.supplier.legalNameLocal
                            }

                            if (workflowData.data.supplier.supplierSpecialtyId) {
                                console.log("TTTTT", $scope.agentTypes)

                                $scope.supplierInfo.agentType = parseInt(workflowData.data.supplier.supplierSpecialtyId);
                            }

                            if (workflowData.data.supplier.legalTax && workflowData.data.supplier.legalTax.countryId) {
                                $scope.addNewData.country = workflowData.data.supplier.legalTax.countryId;
                                $rootScope.incCountryValidation = workflowData.data.supplier.legalTax.countryId;
                                $scope.dependantTaxClassify(workflowData.data.supplier.legalTax.countryId);
                            } else {
                                $rootScope.incCountryValidation = workflowData.data.supplier.countryId;
                                angular.forEach($scope.chooseCountries, function (item, index) {
                                    if (item.id == workflowData.data.supplier.countryId) {
                                        $scope.addNewData.country = item.code;
                                        $scope.dependantTaxClassify(item.code);
                                    }
                                });
                            }

                            if (workflowData.data.supplier.legalTax.isDisregardedEntityForUS == true) {
                                $scope.disregardEnt = 1;
                                $scope.disRegardSection = true;
                            } else {
                                $scope.disregardEnt = 0;
                            }
                            if (workflowData.data.supplier.legalTax.taxRegistrationNumber) {
                                $scope.registrationNoFilledFormSupplier = (workflowData.data.supplier.legalTax) ? workflowData.data.supplier.legalTax.taxRegistrationNumber : '';
                                $scope.supplierInfo.registrationNumber = (workflowData.data.supplier.legalTax) ? workflowData.data.supplier.legalTax.taxRegistrationNumber : '';
                            }

                            if (workflowData.data.supplier.legalTax.taxClassificationId && workflowData.data.supplier.legalTax.countryId) {
                                supplier.withHoldingTaxTypes(workflowData.data.supplier.legalTax.countryId).then(function (data) {
                                    angular.forEach(data, function (item, index) {
                                        if (item.id == workflowData.data.supplier.legalTax.taxClassificationId) {
                                            $scope.supplierInfo.taxClassification = item.name;
                                            if ($scope.supplierInfo.taxClassification) {
                                                angular.forEach($scope.withHoldingTypes, function (item, index) {
                                                    if (item.name == $scope.supplierInfo.taxClassification) {
                                                        $scope.maskingCheck = item.individual;
                                                        if ($scope.maskingCheck == true) {
                                                            $scope.supplierInfo.registrationNumber = (workflowData.data.supplier.legalTax) ? workflowData.data.supplier.legalTax.taxRegistrationNumber.replace('-', '').replace(/\d(?=\d{4})/g, "*") : '';
                                                        } else {
                                                            $scope.supplierInfo.registrationNumber = (workflowData.data.supplier.legalTax) ? workflowData.data.supplier.legalTax.taxRegistrationNumber : '';
                                                        }
                                                    }

                                                });
                                            }
                                        }
                                    });
                                });


                            }
                            //                              if(workflowData.data.supplier.legalTax.taxRegistrationNumber){
                            //                                  $scope.supplierInfo.taxIdentificationNumber = workflowData.data.supplier.legalTax.taxRegistrationNumber; 
                            //   
                            $scope.loader = true;
                            if (workflowData.data.supplier.legalTax.ownerLegalname) {
                                $scope.supplierInfo.ownerLegalName = workflowData.data.supplier.legalTax.ownerLegalname;
                            }
                            if (workflowData.data.supplier.legalTax.ownerCountry) {
                                $scope.dependentTaxForOwnerCountry(workflowData.data.supplier.legalTax.ownerCountry);
                                $scope.supplierInfo.ownerCountry = workflowData.data.supplier.legalTax.ownerCountry;
                            }
                            if (workflowData.data.supplier.legalTax.ownerTaxClassificationId) {

                                $scope.dependentTaxForOwnerCountry(workflowData.data.supplier.legalTax.ownerCountry);
                                $scope.supplierInfo.taxClassificationOwner = workflowData.data.supplier.legalTax.ownerTaxClassificationId;
                            }
                            if (workflowData.data.supplier.legalTax.ownerTaxRegistrationNumber) {
                                $scope.supplierInfo.ownerTaxIdNo = workflowData.data.supplier.legalTax.ownerTaxRegistrationNumber
                            }
                            if (workflowData.data.supplier.legalTax.w9DocId) {
                                $scope.supplierInfo.w9DocId = workflowData.data.supplier.legalTax.w9DocId;
                                $scope.fileDownload_W9 = true;
                                var getId = document.getElementById('downloadUrlForFile_W9');
                                if (getId) {
                                    getId.href = constants.FILE_DOWNLOAD + workflowData.data.supplier.legalTax.w9DocId;
                                }
                                supplier.getlistFileUploaded($scope.supplierInfo.w9DocId).then(function (data) {
                                    $scope.fileNameW9 = data.FileName;
                                }, function (data) {});
                            }
                            if (workflowData.data.supplier.legalTax.exemptDocumentId) {
                                $scope.supplierInfo.exemptDocumentId = workflowData.data.supplier.legalTax.exemptDocumentId;
                                $scope.fileDownload_taxExempt = true;
                                var getId = document.getElementById('downloadUrlForFile_taxExempt');
                                if (getId) {
                                    getId.href = constants.FILE_DOWNLOAD + workflowData.data.supplier.legalTax.exemptDocumentId;
                                }
                                supplier.getlistFileUploaded($scope.supplierInfo.exemptDocumentId).then(function (data) {
                                    $scope.fileNameTaxExempt = data.FileName;
                                }, function (data) {});
                            }
                            if (workflowData.data.supplier.legalTax.documentId) {
                                $scope.supplierInfo.taxRegDocumentId = workflowData.data.supplier.legalTax.documentId;
                                $scope.fileDownload_TaxRegistration = true;
                                var getId = document.getElementById('downloadUrlForFile_TaxRegistration');
                                if (getId) {
                                    getId.href = constants.FILE_DOWNLOAD + workflowData.data.supplier.legalTax.documentId;
                                }
                                supplier.getlistFileUploaded($scope.supplierInfo.taxRegDocumentId).then(function (data) {
                                    $scope.fileNameTaxReg = data.FileName;
                                }, function (data) {});
                            }

                            if (workflowData.data.supplier.legalTax.taxRegistrationNumber) {
                                $scope.mainTaxNo = (workflowData.data.supplier.legalTax) ? workflowData.data.supplier.legalTax.taxRegistrationNumber : '';

//                                $scope.supplierInfo.registrationNumber = (workflowData.data.supplier.legalTax)?workflowData.data.supplier.legalTax.taxRegistrationNumber.replace(/\d(?=\d{4})/g, "*") : '';
                                $scope.supplierInfo.taxIdentificationNumber = workflowData.data.supplier.legalTax.taxRegistrationNumber;
                            }

                            if (workflowData.data.supplier.legalTax.isLawOrMedicalOrHealthCare == true) {
                                $scope.medicalHealth = 1;
                            } else {
                                $scope.medicalHealth = 0;
                            }
                            if (workflowData.data.supplier.legalTax.exemptFromWithholdingTax) {
                                $scope.supplierInfo.exemptCheckBox = 1;
                            }

                            if (workflowData.data.supplier.crossBorderTax) {
                                $scope.taxTable = workflowData.data.supplier.crossBorderTax;
                            }
                            if (workflowData.data.supplier.vat) {
                                $scope.vatlist = workflowData.data.supplier.vat;
                            }


                            if (workflowData.data.supplier.crossBorderTax[0] == undefined) {

                                $scope.initalGoodTypeListing();
                                $scope.supplierInfo.goodTypes = [""];
                                $rootScope.goodTypesValidation = [""];

                            } else {
                                $scope.initalGoodTypeListing();
                                $scope.supplierInfo.types = workflowData.data.supplier.crossBorderTax[0].providedProductId;
                                //                              $rootScope.goodTypesValidation=workflowData.data.supplier.providedProductIds;
                            }
                        }

                    }, function (data) {
                        $scope.loader = false;
                    });

                }

            });
        }



    }, function (data) {
        $scope.loader = false;
        toaster.pop('error', "getAvailableTask API Failed");
    });




    supplier.getAgentTypes().then(function (data) {
        $scope.agentTypes = data;
    }, function () {
        toaster.pop('error', "Country list", "server not responding");
    });


    supplier.getCountryList().then(function (data) {
        $scope.chooseCountries = data;
    }, function () {
        toaster.pop('error', "Country list", "server not responding");
    });



    $scope.$watch('medicalHealth', function (value) {

        if (value == 1) {
            $scope.medicalHealth = true;
        } else if (value == 0) {
            $scope.medicalHealth = false;
        }
    });

    $scope.$watch('disregardEnt', function (value) {
        $scope.change = true;
        if (value == 1) {
            $scope.disRegardSection = true;
            $rootScope.disRegardSection = true;
            $scope.funcProvidingValidation($rootScope.incCountryValidation, $rootScope.taxClassifyValidation, $rootScope.exemptCheckBox, $rootScope.disRegardSection);
        } else if (value == 0) {
            $scope.disRegardSection = false;
            $rootScope.disRegardSection = false;
            $scope.funcProvidingValidation($rootScope.incCountryValidation, $rootScope.taxClassifyValidation, $rootScope.exemptCheckBox, $rootScope.disRegardSection);
        }
    });




    $scope.saveVatListButton = function () {
        console.log($scope.vatlist);
    }

    $scope.$watch('supplierInfo.exemptCheckBox', function (value) {
        $scope.change = true
        if (value == 1) {
            $scope.supplierInfo.exemptCheckBox = true;
            $rootScope.exemptCheckBox = true;
            $scope.funcProvidingValidation($rootScope.incCountryValidation, $rootScope.taxClassifyValidation, $rootScope.exemptCheckBox, $rootScope.disRegardSection);
        } else if (value == 0) {
            $scope.supplierInfo.exemptCheckBox = false;
            $rootScope.exemptCheckBox = false;
            $scope.funcProvidingValidation($rootScope.incCountryValidation, $rootScope.taxClassifyValidation, $rootScope.exemptCheckBox, $rootScope.disRegardSection);
        }
    });

    $scope.agentDrop = function (id) {

    }



    $scope.funcProvidingValidation = function (incCountry, taxClassify, insideUs, providings) {

        $scope.loader = true;
        var country = isNaN($rootScope.incCountryValidation)
        if (country == true) {
            angular.forEach($scope.chooseCountries, function (item, index) {
                if (item.code == $rootScope.incCountryValidation) {

                    $rootScope.incCountryValidation = item.id;
                }
            });
            if ($scope.change == true) {
                var ruleObj = {
                    "request": {
                        "countryId": $rootScope.incCountryValidation,
                        "taxClassificationId": $rootScope.taxClassifyValidation,
                        "exemptFromWithholdingTax": $rootScope.exemptCheckBox,
                        "isDisregardedEntityForUS": $rootScope.disRegardSection,
                        "erpIds": ($rootScope.erpId) ? $rootScope.erpId : [],
                        "crossBorderTaxes": [{
                                "id": 123,
                                "exemptFromWithholdingTax": $rootScope.exemptCheckBox,
                                "providedProductId": $rootScope.goodNewTypeValidation

                            }]
                    }

                };
                supplier.getCompanyPageUiVisibility(ruleObj).then(function (data) {
                    $scope.loader = true
                    $scope.dataUIVisibility = data.data;
                    if ($scope.dataUIVisibility.crossBorderTax[0].documentId.enabled == true) {
                        $scope.headText = "Document"
                    }
                    if ($scope.dataUIVisibility.crossBorderTax[0].exemptDocumentId.enabled == true) {
                        $scope.headText = "Exempt Document"
                    }
                    if ($scope.dataUIVisibility.crossBorderTax[0].w8DocId.enabled == true) {
                        $scope.headText = "w8 Document"
                    }
                    if ($scope.dataUIVisibility.crossBorderTax[0].w8BenDocId.enabled == true) {
                        $scope.headText = "W8 Ben Document"
                    }
                    if ($scope.dataUIVisibility.crossBorderTax[0].form8233DocId.enabled == true) {
                        $scope.headText = "Form 8233 Document"
                    }
                    $scope.loader = false;
                }, function (data) {
                    $scope.loader = false;
                });

            }
        } else {
            if ($scope.change == true) {
                $scope.loader = true;
                var ruleObj = {
                    "request": {
                        "countryId": $rootScope.incCountryValidation,
                        "taxClassificationId": $rootScope.taxClassifyValidation,
                        "exemptFromWithholdingTax": $rootScope.exemptCheckBox,
                        "isDisregardedEntityForUS": $rootScope.disRegardSection,
                        "erpIds": ($rootScope.erpId) ? $rootScope.erpId : [],
                        "crossBorderTaxes": [{
                                "id": 123,
                                "exemptFromWithholdingTax": $rootScope.exemptCheckBox,
                                "providedProductId": $rootScope.goodNewTypeValidation

                            }]
                    }

                };
                supplier.getCompanyPageUiVisibility(ruleObj).then(function (data) {
                    $scope.loader = true
                    $scope.dataUIVisibility = data.data;
                    if ($scope.dataUIVisibility.crossBorderTax[0].documentId.enabled == true) {
                        $scope.headText = "Document"
                    }
                    if ($scope.dataUIVisibility.crossBorderTax[0].exemptDocumentId.enabled == true) {
                        $scope.headText = "Exempt Document"
                    }
                    if ($scope.dataUIVisibility.crossBorderTax[0].w8DocId.enabled == true) {
                        $scope.headText = "w8 Document"
                    }
                    if ($scope.dataUIVisibility.crossBorderTax[0].w8BenDocId.enabled == true) {
                        $scope.headText = "W8 Ben Document"
                    }
                    if ($scope.dataUIVisibility.crossBorderTax[0].form8233DocId.enabled == true) {
                        $scope.headText = "Form 8233 Document"
                    }
                    $scope.loader = false;
                }, function (data) {
                    $scope.loader = false;
                });



//   $scope.loader=false;
            }
        }



    }


    $scope.maskTaxReg = function (taxno) {
        $scope.mainTaxNo = taxno;
        if ($scope.maskingToBeDone == true) {
            taxno = taxno.split('-').join('');
            $scope.supplierInfo.registrationNumber = taxno.replace(/\d(?=\d{4})/g, "*");
        }
    }

    $scope.selection = [];
    $scope.selectionNames = [];


    $scope.changeCountryForTextChange = function (country) {
        if (country == 'US') {
            $scope.w9MainHeading = "IRS W-9 Document: ";
            $scope.DownloadW9Form = "Download W-9 Form from IRS :";
        } else {
            $scope.w9MainHeading = "Text Document: ";
            $scope.DownloadW9Form = "Download Text Document Form from IRS :";
        }
    }
    $scope.checkVatTaxApi = function (supplierInfo) {
        if (supplierInfo.taxAuthority == undefined) {
            toaster.pop('error', "Vat Tax ", "Please select Tax Authority");
            return;
        }
        $scope.loader = true;
        supplier.checkVatTaxApiValidation(supplierInfo).then(function (data) {
//            $scope.loader = false;
            if (data.data == "true") {
                $scope.checkVatTaxApiValidation = true;
                toaster.pop('success', "Vat Tax Validation", "Tax ID is  valid")
            } else {
//                $scope.loader = false;
                $scope.checkVatTaxApiValidation = false;
                toaster.pop('error', "Vat Tax Validation", "Tax ID is not valid")
            }

        }, function (data) {
//            $scope.loader = false;
            toaster.pop('error', "Vat Tax Validation", " Vat Tax ID API not responding")
        });
    }
    $scope.taxCheckValidationApi = function (supplierInfo, addNewData) {
        $scope.loader = true;
        supplier.checkTaxApiValidation(supplierInfo, addNewData).then(function (data) {
            if (data.data == true) {
//                    $scope.loader = false;
                $scope.checkTaxApiValidation = true;
                //              toaster.pop('success', " Tax Validation", "Tax ID is  valid")
            } else {
//                    $scope.loader = false;
                $scope.checkTaxApiValidation = false;
                toaster.pop('error', " Tax Validation", "Tax ID is not valid")
            }

        }, function (data) {
//                $scope.loader = false;
            toaster.pop('error', "Tax Validation", "Tax ID API not responding")
        });
    }
    //
    //  $scope.vatGstIcons=false;
    //  
    //  
    //  $scope.supplierInfo.type = 'Manufacturer';
    var cookie = $cookieStore.get("sc_token");
    $scope.eventId = "";
    $scope.getCurrentIdFound = "";
    var eventIdTrack;
    var currentId;
    $scope.fileDownload_W9 = false;
    $scope.fileDownload_TaxRegistration = false;
    $scope.fileDownload_taxExemptDoc = false;
    $scope.fileDownload_VatDocument = false;
    var dropbox1 = document.getElementById("dropbox_W9");
    var dropbox2 = document.getElementById("dropbox_TaxRegistration");
    var dropbox3 = document.getElementById("dropbox_taxExempt");
    var dropbox4 = document.getElementById("dropbox_VatDoc");
    var dropbox5 = document.getElementById("dropbox_CrossDownload");

    function dragEnterLeave(evt) {
        $("#uploadFile").trigger('change');
        evt.stopPropagation()
        evt.preventDefault()
        $scope.$apply(function () {
            $scope.dropText = 'Drop files here...'
            $scope.dropClass = ''
        })
    }
    //For dropbox1
    dropbox1.addEventListener("dragenter", dragEnterLeave, false)
    dropbox1.addEventListener("dragleave", dragEnterLeave, false)
    dropbox1.addEventListener("dragover", function (evt) {
        $($scope.getCurrentIdFound).css("background-color", "#eaf1f8");
        currentId = evt.currentTarget.id;
        $scope.getCurrentIdFound = "#" + currentId;
        eventIdTrack = evt.currentTarget.id.split('_');
        $($scope.getCurrentIdFound).css("background-color", "orange");
        $scope.eventId = eventIdTrack[1];
        evt.stopPropagation()
        evt.preventDefault()
        var clazz = 'not-available'
        var ok = evt.dataTransfer && evt.dataTransfer.types && evt.dataTransfer.types.indexOf('Files') >= 0
        $scope.$apply(function () {
            $scope.dropText = ok ? 'Drop files here...' : 'Only files are allowed!'
            $scope.dropClass = ok ? 'over' : 'not-available'
        })
    }, false)
    dropbox1.addEventListener("drop", function (evt) {
        evt.stopPropagation()
        evt.preventDefault()
        $scope.$apply(function () {
            $scope.dropText = 'Drop files here...'
            $scope.dropClass = ''
        })
        var files = evt.dataTransfer.files
        if (files.length > 0) {
            $scope.$apply(function () {
                $scope.files = []
                for (var i = 0; i < files.length; i++) {
                    $scope.files.push(files[i])
                    uploadFileSend($scope.files[0]);
                }
            })
        }
    }, false)

    //for dropbox2
    dropbox2.addEventListener("dragenter", dragEnterLeave, false)
    dropbox2.addEventListener("dragleave", dragEnterLeave, false)
    dropbox2.addEventListener("dragover", function (evt) {
        $($scope.getCurrentIdFound).css("background-color", "#eaf1f8");
        currentId = evt.currentTarget.id;
        $scope.getCurrentIdFound = "#" + currentId;
        eventIdTrack = evt.currentTarget.id.split('_');
        $($scope.getCurrentIdFound).css("background-color", "orange");
        $scope.eventId = eventIdTrack[1];
        evt.stopPropagation()
        evt.preventDefault()
        var clazz = 'not-available'
        var ok = evt.dataTransfer && evt.dataTransfer.types && evt.dataTransfer.types.indexOf('Files') >= 0
        $scope.$apply(function () {
            $scope.dropText = ok ? 'Drop files here...' : 'Only files are allowed!'
            $scope.dropClass = ok ? 'over' : 'not-available'
        })
    }, false)
    dropbox2.addEventListener("drop", function (evt) {
        evt.stopPropagation()
        evt.preventDefault()
        $scope.$apply(function () {
            $scope.dropText = 'Drop files here...'
            $scope.dropClass = ''
        })
        var files = evt.dataTransfer.files
        if (files.length > 0) {
            $scope.$apply(function () {
                $scope.files = []
                for (var i = 0; i < files.length; i++) {
                    $scope.files.push(files[i])
                    uploadFileSend($scope.files[0]);
                }
            })
        }
    }, false)

    // for dropbox3
    dropbox3.addEventListener("dragenter", dragEnterLeave, false)
    dropbox3.addEventListener("dragleave", dragEnterLeave, false)
    dropbox3.addEventListener("dragover", function (evt) {
        $($scope.getCurrentIdFound).css("background-color", "#eaf1f8");
        currentId = evt.currentTarget.id;
        $scope.getCurrentIdFound = "#" + currentId;
        eventIdTrack = evt.currentTarget.id.split('_');
        $($scope.getCurrentIdFound).css("background-color", "orange");
        $scope.eventId = eventIdTrack[1];
        evt.stopPropagation()
        evt.preventDefault()
        var clazz = 'not-available'
        var ok = evt.dataTransfer && evt.dataTransfer.types && evt.dataTransfer.types.indexOf('Files') >= 0
        $scope.$apply(function () {
            $scope.dropText = ok ? 'Drop files here...' : 'Only files are allowed!'
            $scope.dropClass = ok ? 'over' : 'not-available'
        })
    }, false)
    dropbox3.addEventListener("drop", function (evt) {
        evt.stopPropagation()
        evt.preventDefault()
        $scope.$apply(function () {
            $scope.dropText = 'Drop files here...'
            $scope.dropClass = ''
        })
        var files = evt.dataTransfer.files
        if (files.length > 0) {
            $scope.$apply(function () {
                $scope.files = []
                for (var i = 0; i < files.length; i++) {
                    $scope.files.push(files[i])
                    uploadFileSend($scope.files[0]);
                }
            })
        }
    }, false)

    //for dropbox4
    dropbox4.addEventListener("dragenter", dragEnterLeave, false)
    dropbox4.addEventListener("dragleave", dragEnterLeave, false)
    dropbox4.addEventListener("dragover", function (evt) {
        $($scope.getCurrentIdFound).css("background-color", "#eaf1f8");
        currentId = evt.currentTarget.id;
        $scope.getCurrentIdFound = "#" + currentId;
        eventIdTrack = evt.currentTarget.id.split('_');
        $($scope.getCurrentIdFound).css("background-color", "orange");
        $scope.eventId = eventIdTrack[1];
        evt.stopPropagation()
        evt.preventDefault()
        var clazz = 'not-available'
        var ok = evt.dataTransfer && evt.dataTransfer.types && evt.dataTransfer.types.indexOf('Files') >= 0
        $scope.$apply(function () {
            $scope.dropText = ok ? 'Drop files here...' : 'Only files are allowed!'
            $scope.dropClass = ok ? 'over' : 'not-available'
        })
    }, false)
    dropbox4.addEventListener("drop", function (evt) {
        evt.stopPropagation()
        evt.preventDefault()
        $scope.$apply(function () {
            $scope.dropText = 'Drop files here...'
            $scope.dropClass = ''
        })
        var files = evt.dataTransfer.files
        if (files.length > 0) {
            $scope.$apply(function () {
                $scope.files = []
                for (var i = 0; i < files.length; i++) {
                    $scope.files.push(files[i])
                    uploadFileSend($scope.files[0]);
                }
            })
        }
    }, false)

    //for dropbox5
    dropbox5.addEventListener("dragenter", dragEnterLeave, false)
    dropbox5.addEventListener("dragleave", dragEnterLeave, false)
    dropbox5.addEventListener("dragover", function (evt) {
        $($scope.getCurrentIdFound).css("background-color", "#eaf1f8");
        currentId = evt.currentTarget.id;
        $scope.getCurrentIdFound = "#" + currentId;
        eventIdTrack = evt.currentTarget.id.split('_');
        $($scope.getCurrentIdFound).css("background-color", "orange");
        $scope.eventId = eventIdTrack[1];
        evt.stopPropagation()
        evt.preventDefault()
        var clazz = 'not-available'
        var ok = evt.dataTransfer && evt.dataTransfer.types && evt.dataTransfer.types.indexOf('Files') >= 0
        $scope.$apply(function () {
            $scope.dropText = ok ? 'Drop files here...' : 'Only files are allowed!'
            $scope.dropClass = ok ? 'over' : 'not-available'
        })
    }, false)
    dropbox5.addEventListener("drop", function (evt) {
        evt.stopPropagation()
        evt.preventDefault()
        $scope.$apply(function () {
            $scope.dropText = 'Drop files here...'
            $scope.dropClass = ''
        })
        var files = evt.dataTransfer.files
        if (files.length > 0) {
            $scope.$apply(function () {
                $scope.files = []
                for (var i = 0; i < files.length; i++) {
                    $scope.files.push(files[i])
                    uploadFileSend($scope.files[0]);
                }
            })
        }
    }, false)


    //============== DRAG & DROP =============

    $scope.setFiles = function (element) {
        var getElementId = element.id.split('_');
        $scope.eventId = getElementId[1];
        $scope.$apply(function ($scope) {
            $scope.files = []
            for (var i = 0; i < element.files.length; i++) {
                $scope.files.push(element.files[i]);
                uploadFileSend($scope.files[0])
            }
        });
    };
    //  
    function uploadFileSend(file) {
        $scope.loader = true;
        console.log("supplierApiUrl", constants.SUPPLIER_API_URL);
        console.log("file", file);
        $($scope.getCurrentIdFound).css("background-color", "#eaf1f8");
        $scope.preloader = true;
        $scope.fileName = file.name;
        var formData = new FormData();
        formData.append('file', file);
        formData.append('SUPPLIERID', localStorage.getItem("userId"));
        console.log("formData", formData)
        var req = {
            method: 'POST',
            /*'https://pc-api-gateway-dev.run.asv-pr.ice.predix.io/pc_document_management/supplier/document/push?docType='+$scope.eventId,*/
            url: constants.FILE_UPLOAD + $scope.eventId,
            transformRequest: angular.identity,
            headers: {
                'Content-Type': undefined,
                'Authorization': WorkFlow.getCookieVal()
            },
            data: formData,
            cache: false,
            contentType: false,
            processData: false
        };
        $http(req).then(function (data) {
            debugger;
            var divAttribute;
            var downloadUrl;
            var userId = localStorage.getItem("userId");
            $scope.getCurrentIdFound = "";
            $scope.eventId = "";
            $scope.preloader = false;
            var pJson = data.data;
            var finalUrlData = pJson.key;
            var dataFile = finalUrlData.split(':');
            var docName = data.data.docType;
            var specificFileName = dataFile[3];
            //var downloadUrl=constants.SUPPLIER_API_URL+"supplier/document/pull?SUPPLIERID="+localStorage.getItem("userId")+"&filename="+dataFile[2];
            //$("#downloadUrlForFile").attr("href", downloadUrl) 
            $scope.loader = false;
            toaster.pop('success', "Document Upload", "Document had been uploaded successfully");
            //$('#fileShow').show();
            if (dataFile[1] == "W9") {
                $scope.fileDownload_W9 = true;
                $scope.fileNameW9 = dataFile[3];
                downloadUrl = data.data.filePath;
                $scope.supplierInfo.w9DocName = $scope.fileNameW9;
                $scope.supplierInfo.w9Path = downloadUrl.split('/');
                $scope.supplierInfo.w9DocId = $scope.supplierInfo.w9Path[5];
                divAttribute = document.getElementById('downloadUrlForFile_W9');
                divAttribute.href = constants.FILE_DOWNLOAD + localStorage.getItem("userId") + '-' + data.data.fileId + '-' + data.data.docType;
                ;
            } else if (dataFile[1] == "TaxReg") {
                $scope.fileDownload_TaxRegistration = true;
                //                  getlistFileUploaded(userId,docName);                        
                $scope.fileNameTaxReg = dataFile[3];
                downloadUrl = data.data.filePath;
                $scope.supplierInfo.taxRegistrationDocPath = downloadUrl.split('/')
                $scope.supplierInfo.taxRegDocumentId = $scope.supplierInfo.taxRegistrationDocPath[5];
                divAttribute = document.getElementById('downloadUrlForFile_TaxRegistration');
                divAttribute.href = constants.FILE_DOWNLOAD + localStorage.getItem("userId") + '-' + data.data.fileId + '-' + data.data.docType;
                ;

            } else if (dataFile[1] == "taxExempt") {
                $scope.fileDownload_taxExempt = true;
                //                      getlistFileUploaded(userId,docName);
                $scope.fileNameTaxExempt = dataFile[3];
                downloadUrl = data.data.filePath;
                $scope.supplierInfo.taxExemptDocPath = downloadUrl.split('/');
                $scope.supplierInfo.exemptDocumentId = $scope.supplierInfo.taxExemptDocPath[5];
                divAttribute = document.getElementById('downloadUrlForFile_taxExempt');
                divAttribute.href = constants.FILE_DOWNLOAD + localStorage.getItem("userId") + '-' + data.data.fileId + '-' + data.data.docType;
                ;
            } else if (dataFile[1] == "VatDoc") {
                $scope.fileDownload_VatDocument = true;
                $scope.fileNameVat = dataFile[3];
                downloadUrl = data.data.filePath;
                $scope.supplierInfo.vatDocPath = downloadUrl.split('/').pop();
                //$scope.supplierInfo.vatDocId=$scope.supplierInfo.vatDocPath;
                divAttribute = document.getElementById('downloadUrlForFile_VatDocument');
                divAttribute.href = constants.FILE_DOWNLOAD + localStorage.getItem("userId") + '-' + data.data.fileId + '-' + data.data.docType;
                ;
            } else if (dataFile[1] == "CrossDownload") {
                $scope.fileDownload_CrossDownload = true;
                $scope.crossFileName = dataFile[3];
                downloadUrl = data.data.filePath;
                $scope.supplierInfo.vatDocPath = downloadUrl.split('/').pop();
                //$scope.supplierInfo.vatDocId=$scope.supplierInfo.vatDocPath;
                divAttribute = document.getElementById('downloadUrlForFile_CrossDownload');
                divAttribute.href = constants.FILE_DOWNLOAD + localStorage.getItem("userId") + '-' + data.data.fileId + '-' + data.data.docType;
                ;
            }

        }, function () {
            $scope.loader = false;
            $scope.eventId = "";
            $scope.getCurrentIdFound = "";
            $scope.preloader = false;
            toaster.pop('error', "Document Upload", "server not responding");
        });

    }

    $scope.deleteUploadFile = function () {

    }

    /* ***********************COMPANY PAGE SAVE START********************************************** */

    $scope.nextProfileCompany = function (supplierInfo, addNewData, text) {


        $scope.mainCompanyFunction = function () {

            if (!supplierInfo.taxClassification) {
                toaster.pop('error', "Tax Classification is missing", "Please fill tax Authority");
                $('#tax_classify_box').addClass("invalid");
                $("html, body").animate({
                    scrollTop: 900
                }, 1000);
                return
            }
            if (!supplierInfo.registrationNumber) {
                toaster.pop('error', "Tax Registration Number is missing", "Please fill tax resitration Number");
                $('#tax_valid_box').addClass("invalid");
                $("html, body").animate({
                    scrollTop: 800
                }, 1000);
                return
            }



            if (supplierInfo.taxClassification && supplierInfo.registrationNumber && addNewData.country) {
                supplier.checkTaxApiValidation(supplierInfo, addNewData, $scope.mainTaxNo).then(function (data) {
                    $scope.loader = true;
                    if (data.data == true) {
                        $scope.loader = false;
                        $('#tax_valid_box').removeClass("invalid");
                        $('#tax_valid_box').addClass("form-control");
                        $scope.checkTaxApiValidation = true;

                        ///////////////////////////MAIN FUNCTION///////////////////////////////////
                        $scope.loader = true;
                        WfModel.supplier = (WfModel.supplier == null) ? {} : WfModel.supplier;
                        WfModel.supplier.legalTax = (WfModel.supplier.legalTax == null) ? {} : WfModel.supplier.legalTax;
                        WfModel.supplier.crossBorderTax = (WfModel.supplier.crossBorderTax == null) ? [] : WfModel.supplier.crossBorderTax;
                        WfModel.supplier.vat = (WfModel.supplier.vat == null) ? [] : WfModel.supplier.vat;

                        WfModel.supplier.legalNameLocal = supplierInfo.legalLanguagename;
                        WfModel.supplier.legalName = addNewData.name;
                        WfModel.supplier.supplierSpecialtyId = supplierInfo.agentType;
                        WfModel.supplier.legalTax.taxClassificationId = $rootScope.taxClassifyValidation;
                        WfModel.supplier.legalTax.taxRegistrationNumber = $scope.mainTaxNo;
                        WfModel.supplier.legalTax.isLawOrMedicalOrHealthCare = $scope.medicalHealth;
                        WfModel.supplier.legalTax.isDisregardedEntityForUS = $scope.disRegardSection;
                        WfModel.supplier.legalTax.ownerLegalname = supplierInfo.ownerLegalName;
                        WfModel.supplier.legalTax.ownerCountry = supplierInfo.ownerCountry;
                        WfModel.supplier.legalTax.ownerTaxClassificationId = supplierInfo.taxClassificationOwner;
                        WfModel.supplier.legalTax.ownerTaxRegistrationNumber = supplierInfo.ownerTaxIdNo;
                        WfModel.supplier.legalTax.countryId = addNewData.country;
                        WfModel.supplier.legalTax.documentId = $scope.supplierInfo.taxRegDocumentId;
                        WfModel.supplier.legalTax.w9DocId = $scope.supplierInfo.w9DocId;
                        WfModel.supplier.legalTax.exemptFromWithholdingTax = $scope.supplierInfo.exemptCheckBox;
                        WfModel.supplier.legalTax.exemptDocumentId = $scope.supplierInfo.exemptDocumentId;
                        WfModel.supplier.crossBorderTax = $scope.taxTable;
                        WfModel.supplier.vat = $scope.vatlist;
                        WfModel.supplier.alternateId = [{
                                "type": "DBA",
                                "value": supplierInfo.dbaName
                            }];
                        WorkFlow.setVariablesV2(WfModel).then(function (data) {
                            $scope.loader = false;
                            if (text == "next") {
                                $state.go('supplierProfileAddress');
                                $scope.change = false;
                            }
                            $rootScope.supplierProfileCompanyDone = true;
                            toaster.pop('success', "Saved successfully");
                            $scope.supplierInfo.country3 = '';
                            $scope.supplierInfo.taxAuthority = '';
                            $scope.fileNameVat = '';
                            $scope.supplierInfo.taxIdInVat = '';
                            $scope.vatFileNameUrl = '';
                            $scope.vatFileName = '';

                        }, function (data) {
                            $scope.loader = false;
                            toaster.pop('error', "Workflow Api failed", "Server not Responding");
                        });

                        ////////////////////MAIN FUNCTION ENDS       



                    } else {
                        $scope.loader = false;
                        $('#tax_valid_box').addClass("invalid");
                        $("html, body").animate({
                            scrollTop: 1000
                        }, 1000);
                        $scope.loader = false;
                        $scope.checkTaxApiValidation = false;
                        toaster.pop('error', " Tax Validation", "Tax ID is not valid");
                        return
                    }

                }, function (data) {
                    $scope.loader = false;
                    toaster.pop('error', "Tax Validation", "Tax ID API not responding")
                });
            }
        }


        $scope.nextCrossFunction = function () {
            if (supplierInfo.crossCountry != undefined && supplierInfo.crossCountry != "" && supplierInfo.taxIdentNo != undefined && supplierInfo.taxIdentNo != "") {
                $scope.taxTable.push({
                    countryId: supplierInfo.crossCountry,
                    providedProductId: supplierInfo.types,
                    taxRegistrationNumber: supplierInfo.taxIdentNo,
                    documentId: $scope.crossFileName,
                    w8DocId: '',
                    w8BenDocId: '',
                    form8233DocId: '',
                    exemptFromWithholdingTax: $scope.supplierInfo.exemptCheckBox,
                    exemptDocumentId: ''
                });
                $scope.crossBorder = true;
                $scope.fileDownload_CrossDownload = false;
                $scope.crossFileName = "";
                $scope.supplierInfo.crossCountry = '';
                $scope.supplierInfo.types = '';
                $scope.supplierInfo.taxIdentNo = '';
                $scope.supplierInfo.goodTypes = [""];
                $rootScope.goodTypesValidation = [""];
                $scope.fileNameTaxRegDocument = '';
                $scope.fileNameTaxExempt = '';
                //          $scope.fileDownload_TaxRegistration=false;
                $scope.fileDownload_taxExemptDoc = false;
                $scope.supplierInfo.taxRegDocument = '';
                $scope.supplierInfo.taxExeDocument = '';
                $scope.mainCompanyFunction();
            } else if ($scope.taxTable.length > 0) {
                $scope.mainCompanyFunction()
            } else if ($scope.dataUIVisibility.crossBorderTax[0].countryId.enabled == true && supplierInfo.crossCountry == undefined || supplierInfo.crossCountry == '') {
                $scope.crossBorder = false;
                toaster.pop('error', "Cross border Section Details Missing", "Please fill all details");

                return
            } else if ($scope.dataUIVisibility.crossBorderTax[0].countryId.enabled == false) {
                $scope.mainCompanyFunction();
            }
        }




        if (supplierInfo.country3 != undefined && supplierInfo.country3 != "" && supplierInfo.taxAuthority != undefined && supplierInfo.taxAuthority != "" && supplierInfo.taxIdInVat != undefined && supplierInfo.taxIdInVat != '') {

            supplier.checkVatTaxApiValidation(supplierInfo).then(function (data) {
                $scope.loader = true;
                if (data.data == "true") {
                    $scope.loader = false;
                    $scope.checkVatTaxApiValidation = true;

                    $scope.vatlist.push({
                        countryId: supplierInfo.country3,
                        taxAuthorityId: supplierInfo.taxAuthority,
                        documentId: $scope.fileNameVat,
                        taxNumber: supplierInfo.taxIdInVat,
                        fileUrl: $scope.vatFileNameUrl
                    });
                    $scope.supplierInfo.country3 = '';
                    $scope.supplierInfo.taxAuthority = '';
                    $scope.fileNameVat = '';
                    $scope.supplierInfo.taxIdInVat = '';
                    $scope.vatFileNameUrl = '';
                    $scope.vatFileName = '';
                    $scope.fileDownload_VatDocument = false;
                    toaster.pop('success', "Vat Tax Validation", "Tax ID is  valid");
                    $scope.nextCrossFunction();

                } else {
                    $scope.loader = false;
                    $scope.checkVatTaxApiValidation = false;
                    toaster.pop('error', "Vat Tax Validation", "Tax ID is not valid");
                    $('#vat_id_box').css('border', '1px solid red');
                    return
                }
            });
        } else if ($scope.vatlist.length > 0) {
            $scope.nextCrossFunction();
        } else if ($scope.dataUIVisibility.vat[0].countryId.enabled == true && supplierInfo.country3 == undefined || supplierInfo.country3 == '') {
            toaster.pop('error', "Vat Section Details Missing", "Please fill all details");
            return
        } else if ($scope.dataUIVisibility.vat[0].countryId.enabled == false) {
            $scope.nextCrossFunction();
        }






        //check for legal entity tax section validation//

//        if($scope.checkTaxApiValidation == false){
//        	toaster.pop('error', " Tax Validation", "Tax ID is not valid");
//            return
//        }
//        ///////////////////////////////////////////////////////
//        if ($scope.checkTaxApiValidation) {
//            if ($scope.checkTaxApiValidation != true) {
//                toaster.pop('error', "Tax Id not valid", "Please fill with correct Tax Id");
//                return
//            }
//        }





        //}                                          
    }


    /* ***********************COMPANY PAGE SAVE ENDS********************************************** */




    //  
    //  /*********************************************************************************************************************/
    //  
    //     $scope.nextProfileCompany=function(supplierInfo,addNewData,text){
    //       $scope.submitted = true;
    //       
    //       if(supplierInfo.country2!=undefined && supplierInfo.country2!="" && supplierInfo.registrationNumber!=undefined && supplierInfo.registrationNumber!=""){
    //           $scope.taxTable.push({countryId:supplierInfo.country2, taxRegistrationNumber: supplierInfo.registrationNumber, documentId: $scope.fileNameTaxRegDocument,taxRefFileUrl:$scope.taxRegFileNameUrl,taxExemptFileUrl:$scope.taxExemptFileNameUrl, exemptDocumentId: $scope.fileNameTaxExempt });
    //       }
    //       if($scope.vatAddedTrue==true){
    //       if(supplierInfo.taxIdInVat!=undefined && supplierInfo.taxIdInVat!="" && supplierInfo.taxAuthority!=undefined && supplierInfo.taxAuthority!="" && supplierInfo.country3!=undefined && supplierInfo.country3!="" ){
    //           $scope.vatlist.push({countryId:supplierInfo.country3,taxAuthorityId:supplierInfo.taxAuthority,documentId:$scope.vatFileName,taxNumber:supplierInfo.taxIdInVat,fileUrl:$scope.vatFileNameUrl});
    //       }
    //       }
    //       else{
    //           if(supplierInfo.taxIdInVat!=undefined && supplierInfo.taxIdInVat!="" && supplierInfo.taxAuthority!=undefined && supplierInfo.taxAuthority!="" && supplierInfo.country3!=undefined && supplierInfo.country3!="" ){
    //               $scope.vatlist.push({countryId:supplierInfo.country3,taxAuthorityId:supplierInfo.taxAuthority,documentId:$scope.vatFileName,taxNumber:supplierInfo.taxIdInVat,fileUrl:$scope.vatFileNameUrl});
    //           } 
    //       }
    //      supplier.checkTaxApiValidation(supplierInfo).then(function(data) {
    //          if(data.data=="true"){
    //              $scope.loader=true;
    //              if($scope.vatAddedTrue==true && $scope.vatSection==true){
    //                  $rootScope.supplierProfileCompanyDone=true;
    //                  supplierInfo.taxTable = $scope.taxTable;
    //                  supplierInfo.vatlist =  $scope.vatlist;
    //                  $scope.supplierInfo.goodTypes=$rootScope.goodTypesValidation;
    //                  
    //                  WfModel.supplier = (WfModel.supplier==null)?{}:WfModel.supplier;
    //                  WfModel.supplier.legalName=addNewData.name;
    //                  WfModel.supplier.localLanguageCode=supplierInfo.legalLanguagename;
    //                  WfModel.supplier.countryId=addNewData.country;
    //                  WfModel.supplier.legalNameLocal=supplierInfo.dbaName;
    //                  WfModel.supplier.taxClassificationId=supplierInfo.taxClassification;
    //                  WfModel.supplier.taxNumber=supplierInfo.taxIdentificationNumber;
    //                  WfModel.supplier.providedProductIds=$scope.supplierInfo.goodTypes;
    //                  WfModel.supplier.taxes=$scope.taxTable;
    //                  WfModel.supplier.vats=$scope.vatlist;
    //                  WfModel.supplier.mainTaxDocumentId = $scope.mainTaxDocumentId;
    //                  WfModel.supplier.otherTaxDocuments=$scope.otherTaxDocuments;
    //                  WorkFlow.setVariablesV2(WfModel).then(function(data){
    //               
    //                      toaster.pop('success', "Saved successfully");
    //                  },function(data){
    //                      toaster.pop('error', "Workflow Api failed");
    //                  });
    //              if(text=="next"){
    //                  $state.go('supplierProfileAddress.legal');       
    //              }   
    //                  
    //              }
    //              else if( $scope.vatSection==true && $scope.vatlist.length>0 ){
    //                  $rootScope.supplierProfileCompanyDone=true;
    //                  supplierInfo.taxTable = $scope.taxTable;
    //                  supplierInfo.vatlist =  $scope.vatlist;
    //                  $scope.supplierInfo.goodTypes=$rootScope.goodTypesValidation;
    //                  
    //                  WfModel.supplier = (WfModel.supplier==null)?{}:WfModel.supplier;
    //                  WfModel.supplier.legalName=addNewData.name;
    //                  WfModel.supplier.localLanguageCode=supplierInfo.legalLanguagename;
    //                  WfModel.supplier.countryId=addNewData.country;
    //                  WfModel.supplier.legalNameLocal=supplierInfo.dbaName;
    //                  WfModel.supplier.taxClassificationId=supplierInfo.taxClassification;
    //                  WfModel.supplier.taxNumber=supplierInfo.taxIdentificationNumber;
    //                  WfModel.supplier.providedProductIds=$scope.supplierInfo.goodTypes;
    //                  WfModel.supplier.taxes=$scope.taxTable;
    //                  WfModel.supplier.vats=$scope.vatlist;
    //                  WfModel.supplier.mainTaxDocumentId = $scope.mainTaxDocumentId;
    //                  WfModel.supplier.otherTaxDocuments=$scope.otherTaxDocuments;
    //                  WorkFlow.setVariablesV2(WfModel).then(function(data){
    //               
    //                      toaster.pop('success', "Saved successfully");
    //                  },function(data){
    //                      toaster.pop('error', "Workflow Api failed");
    //                  });
    //              if(text=="next"){
    //                  $state.go('supplierProfileAddress.legal');       
    //              }
    //              }
    //              else if($scope.vatSection==false || $scope.vatlist.length==0){
    //                  $rootScope.supplierProfileCompanyDone=true;
    //                  supplierInfo.taxTable = $scope.taxTable;
    //                  supplierInfo.vatlist =  $scope.vatlist;
    //                  $scope.supplierInfo.goodTypes=$rootScope.goodTypesValidation;
    //                  supplierInfo.mainTaxDocumentId = $scope.supplierInfo.mainTaxDocumentId;
    //                  WfModel.supplier = (WfModel.supplier==null)?{}:WfModel.supplier;
    //                  WfModel.supplier.legalName=addNewData.name;
    //                  WfModel.supplier.localLanguageCode=supplierInfo.legalLanguagename;
    //                  WfModel.supplier.countryId=addNewData.country;
    //                  WfModel.supplier.legalNameLocal=supplierInfo.dbaName;
    //                  WfModel.supplier.taxClassificationId=supplierInfo.taxClassification;
    //                  WfModel.supplier.taxNumber=supplierInfo.taxIdentificationNumber;
    //                  WfModel.supplier.providedProductIds=$scope.supplierInfo.goodTypes;
    //                  WfModel.supplier.taxes=$scope.taxTable;
    //                  WfModel.supplier.vats=$scope.vatlist;
    //                  WfModel.supplier.mainTaxDocumentId = $scope.supplierInfo.mainTaxDocumentId;
    //                  //WfModel.supplier.otherTaxDocuments=$scope.otherTaxDocuments;
    //                  WorkFlow.setVariablesV2(WfModel).then(function(data){
    //                      $scope.loader=false; 
    //                      toaster.pop('success', "Saved successfully");
    //                  },function(data){
    //                      $scope.loader=false;
    //                      toaster.pop('error', "Workflow Api failed");
    //                  });
    //              if(text=="next"){
    //                  $state.go('supplierProfileAddress.legal');       
    //              }
    //              }
    //              else{
    //                  $scope.loader=false;
    //                  toaster.pop('error', "Please add the vat section");
    //                   return 
    //              }
    //              
    //              return
    //          }
    //          
    //          else{
    //              $scope.loader=false;
    //              toaster.pop('error', " Tax Validation", "Tax ID is not valid");     
    //          }
    //       
    //      });
    //     }
    //     
    //  /*********************************************************************************************************************/
    //     
    //     
    //     

    //  

    //    
    $scope.initalGoodTypeListing = function () {
        supplier.getGoodTypes().then(function (data) {
            $scope.mainGoodTypesList = data;
            $scope.supplierInfo.types = [];
            $scope.getGoodTypesNew = [];
            $scope.getGoodTypesRestored = data;
            angular.forEach($scope.getGoodTypesRestored, function (item, index) {
                $scope.getGoodTypesNew.push(item.name);
                $scope.getGoodTypes = $scope.getGoodTypesNew;

            });

        }, function (data) {
//                $scope.loader = false;
            toaster.pop('error', "Good Types Api Server Not Responding");
        });
    }
    //   
    $scope.GoodTypeListing = function () {
        $scope.loader = true;
        supplier.getGoodTypes().then(function (data) {
//                $scope.loader = false;
            $scope.getGoodTypesNew = [];
            $scope.getGoodTypesRestored = data;
            angular.forEach($scope.getGoodTypesRestored, function (item, index) {
                $scope.getGoodTypesNew.push(item.name);
                $scope.getGoodTypes = $scope.getGoodTypesNew;
            });

        }, function (data) {
            $scope.loader = false;
            toaster.pop('error', "Good Types Api Server Not Responding");
        });
    }
    //   
    //   
    $scope.dependantTaxClassify = function (countryCode) {
        $scope.loader = true;
        $scope.supplierInfo.taxClassification = "";
        supplier.withHoldingTaxTypes(countryCode).then(function (data) {
//            $scope.loader = false;
            $scope.withHoldingTypes = data;
            $rootScope.withHoldingTypesOld = data;
        }, function (data) {
            $scope.loader = false;
            toaster.pop('error', "Tax Types Api Server Not Responding");
        });

    }


    $scope.dependentTaxForOwnerCountry = function (countryCode) {
        $scope.loader = true;

        supplier.withHoldingTaxTypes(countryCode).then(function (data) {
            $scope.loader = false;
            $scope.withHoldingTypesOwner = data;
        }, function (data) {
            $scope.loader = false;
            toaster.pop('error', "Tax Types Api Server Not Responding");
        });

    }


    //   
    $scope.dependantTaxAuthority = function (countryCode) {
        $scope.loader = true;
        angular.forEach($scope.chooseCountries, function (item, index) {
            if (item.id == countryCode) {

                $scope.countryCodeNew = item.code;
            }
        });
        supplier.taxAuthority($scope.countryCodeNew).then(function (data) {
            $scope.loader = false;
            $scope.taxAuthority = data;
        }, function (data) {
            $scope.loader = false;
            toaster.pop('error', "Tax Authority Api Server Not Responding");
        });


    }

    supplier.withHoldingTaxTypes().then(function (data) {
        $scope.withHoldingTypes = data;
    }, function (data) {
        toaster.pop('error', "Tax Types Api Server Not Responding");
    });



    supplier.taxAuthority().then(function (data) {
        $scope.taxAuthority = data;
    }, function (data) {
        toaster.pop('error', "Tax Authority Api Server Not Responding");
    });


    //   $scope.vatlist =[{"country":"india","taxAuthority":"aaaa","taxId":"bbbbb","file":"1111"},{"country":"japan","taxAuthority":"aaaa","taxId":"bbbbb","file":"2222"},{"country":"australia","taxAuthority":"aaaa","taxId":"bbbbb","file":"3333"},{"country":"bangaldesh","taxAuthority":"aaaa","taxId":"bbbbb","file":"4444"}]; 
    //   $scope.taxTable =[{"country":"india","taxNumber":"aaaa","taxRegDocument":"bbbbb","taxExeDocument":"1111"},{"country":"japan","taxNumber":"cccc","taxRegDocument":"ddddd","taxExeDocument":"2222"},{"country":"australia","taxNumber":"eeee","taxRegDocument":"ffff","taxExeDocument":"3333"},{"country":"bangaldesh","taxNumber":"ggggg","taxRegDocument":"hhhh","taxExeDocument":"4444"}]; 

    $scope.moreVatButton = function (supplierInfo) {

        if (!supplierInfo.taxIdInVat && !supplierInfo.country3 && !supplierInfo.taxAuthority) {
            toaster.pop('error', "Please fill all fields");
            return;
        }

        supplier.checkVatTaxApiValidation(supplierInfo).then(function (data) {
//            $scope.loader = false;
            if (data.data == "true") {
                $scope.checkVatTaxApiValidation = true;
                if ($scope.checkVatTaxApiValidation == true) {

                    $scope.vatGstIcons = true;
                    $scope.vatAddedTrue = true;
                    $scope.vatlist.push({
                        countryId: supplierInfo.country3,
                        taxAuthorityId: supplierInfo.taxAuthority,
                        documentId: $scope.fileNameVat,
                        taxNumber: supplierInfo.taxIdInVat
                    });
                    //                  if($scope.fileNameVat!=""){
                    //                      var fileDownloadOptions=document.getElementById('tableVatFileClick')
                    //                      if(fileDownloadOptions){
                    //                      fileDownloadOptions.href=$scope.vatFileNameUrl
                    //                      }
                    //                  } 
                    $scope.supplierInfo.country3 = '';
                    $scope.supplierInfo.taxAuthority = '';
                    $scope.fileNameVat = '';
                    $scope.supplierInfo.taxIdInVat = '';
                    $scope.vatFileNameUrl = '';
                    $scope.vatFileName = '';
                    $scope.fileDownload_VatDocument = false;
                }
                //              toaster.pop('success', "Vat Tax Validation", "Tax ID is  valid")
            } else {
//                $scope.loader = false;
                $scope.checkVatTaxApiValidation = false;
                toaster.pop('error', "Vat Tax Validation", "Tax ID is not valid")
            }
        });



    }


    var searchInput, i;
    searchInput = $scope.vatlist;

    $scope.deletRow = function () {
        console.log("searchInput", $scope.vatlist)
        var no = 0;
        $scope.noSelectedItems = "";

        $scope.index = [];
        i = $scope.vatlist.length;
        angular.forEach($scope.vatlist, function (item, index) {
            if (item.check == true) {
                while (i--) {
                    console.log($scope.vatlist[i].check);
                    if ($scope.vatlist[i].check == true) {
                        no++;
                        $scope.vatlist.splice(i, 1);
                    }
                    $scope.noSelectedItems = no;
                }
                toaster.pop('success', "Vat List", "Row has been deleted successfully  ");
            }



        });
        if ($scope.noSelectedItems.length == 0) {
            toaster.pop('error', "Vat List", "Please choose atleat one row");
            return
        }

    }
    var searchInput2, j;
    searchInput2 = $scope.taxTable;
    $scope.deleteTaxRow = function () {
        var no = 0;
        $scope.noSelectedItemsCross = "";

        j = $scope.taxTable.length;
        angular.forEach($scope.taxTable, function (item, index) {
            if (item.check1 == true) {
                while (j--) {
                    if ($scope.taxTable[j].check1 == true) {
                        $scope.taxTable.splice(j, 1);
                        no++;
                        toaster.pop('success', "Tax Row Deleted", "Row has been deleted successfully ");
                    }
                    $scope.noSelectedItemsCross = no;
                }
            }


        });
        if ($scope.noSelectedItemsCross.length == 0) {
            toaster.pop('error', "Cross Border Tax List", "Please choose atleat one row");
            return
        }
    }


    $scope.editTaxRow = function () {
        var editTaxListRows = $scope.taxTable;
        var index = null;
        var flag = 0;
        angular.forEach($scope.taxTable, function (value, key) {
            if (value.check1) {
                index = key;
                flag++;
            }
        });
        if (flag == 0 || flag > 1) {
            toaster.pop('error', "Cross Border Tax List", "Please choose atleast one row");
            return;
        }
        $scope.supplierInfo.crossCountry = $scope.taxTable[index].countryId;
        $scope.supplierInfo.types = $scope.taxTable[index].providedProductId;
        $scope.supplierInfo.taxIdentNo = $scope.taxTable[index].taxRegistrationNumber;
        if ($scope.taxTable[index].documentId != "" || $scope.taxTable[index].documentId != undefined || $scope.taxTable[index].exemptDocumentId != '' || $scope.taxTable[index].exemptDocumentId != undefined || $scope.taxTable[index].w8DocId != '' || $scope.taxTable[index].w8DocId != undefined || $scope.taxTable[index].w8BenDocId != '' || $scope.taxTable[index].w8BenDocId != undefined || $scope.taxTable[index].form8233DocId != '' || $scope.taxTable[index].form8233DocId != undefined) {
            $scope.fileDownload_CrossDownload = true;
            $scope.crossFileName = $scope.taxTable[index].documentId;
        } else {
            $scope.fileDownload_CrossDownload = false;
        }

        $scope.taxTable.splice(index, 1);
        //    if($scope.taxTable[index]){
        //     if($scope.taxTable[index].taxRegDocument!=""){
        //         $scope.fileDownload_TaxRegistration=true;
        //         $scope.fileNameTaxReg=$scope.taxTable[index].taxRegDocument;
        //    
        //     }
        //  }
        //    if($scope.taxTable[index]){
        //     if($scope.taxTable[index].taxExeDocument!=""){
        //         $scope.supplierInfo.exemptCheckBox=1;
        //         $scope.fileDownload_taxExemptDoc=true;
        //         $scope.fileNameTaxExempt=$scope.taxTable[index].taxExeDocument;
        //    
        //     }
        //    }


    }


    $scope.editVatList = function () {

        var index = null;
        var flag = 0;
        angular.forEach($scope.vatlist, function (value, key) {
            if (value.check) {
                index = key;
                flag++;
            }
        });
        if (flag == 0 || flag > 1) {
            toaster.pop('error', "Vat List", "Please choose one vat list info");
            return;
        }

        $scope.supplierInfo.country3 = parseInt($scope.vatlist[index].countryId);
        if ($scope.supplierInfo.country3) {
            $scope.dependantTaxAuthority($scope.supplierInfo.country3);
        }

        $scope.supplierInfo.taxAuthority = parseInt($scope.vatlist[index].taxAuthorityId);
        $scope.supplierInfo.taxIdInVat = $scope.vatlist[index].taxNumber;
        if ($scope.vatlist[index].documentId != null || $scope.vatlist[index].documentId != undefined) {
            $scope.fileDownload_VatDocument = true;
            document.getElementById('downloadUrlForFile_VatDocument').style.display = "none";
            $scope.fileNameVat = $scope.vatlist[index].documentId;
        } else {
            $scope.fileDownload_VatDocument = false;
        }
        $scope.vatlist.splice(index, 1);
        //     if($scope.vatlist[index].documentId!=""){
        //     $scope.fileDownload_VatDocument=true;  
        //     $scope.vatFileName=$scope.vatlist[index].documentId;
        //     var divAttribute = document.getElementById('downloadUrlForFile_VatDocument');
        //     divAttribute.href = $scope.vatlist[index].fileUrl;
        //     
        //     }
        //    angular.forEach($scope.vatlist, function(item,index){
        //         if(item.check==true){    
        //             $scope.supplierInfo.country3=item.country;
        //             $scope.supplierInfo.taxAuthority=item.taxAuthority;
        //             $scope.supplierInfo.taxIdInVat=item.taxId;
        //             var k=$scope.vatlist.length;
        //              while (k--) {
        //                  if (editVatList[k].check == true) {
        //                      editVatList.splice(k, 1);
        //                  }
        //              }
        //             if(item.file!=""){
        //                 $scope.fileDownload_VatDocument=true;  
        //                 $scope.vatFileName=item.file;
        //                 var divAttribute = document.getElementById('downloadUrlForFile_VatDocument');
        //                 divAttribute.href = item.fileUrl;
        //             }
        //
        //             
        //         }
        //         else{
        //             toaster.pop('error', "Please select any row and click edit button "); 
        //         }
        //    });
    }




    //  
    //  /*Validation API For Incoperation country Should Call here*/    
    $scope.firstCountryChange = function (countryCode) {
        $scope.change = true;
        $rootScope.taxClassifyValidation = '';
        angular.forEach($scope.chooseCountries, function (item, index) {
            if (item.code == countryCode) {
                console.log("item", item)
                $rootScope.incCountryValidation = item.id;
            }
        });
        $scope.funcProvidingValidation($rootScope.incCountryValidation, $rootScope.taxClassifyValidation, $rootScope.exemptCheckBox, $rootScope.disRegardSection);

    }


    /*Validation API for tax Classification change */
    $scope.taxClassificationChange = function (taxName) {
        if (taxName == null || taxName == "") {
            $rootScope.taxClassifyValidation = "";
            $('#tax_classify_box').addClass("invalid");
        } else {
            $('#tax_classify_box').removeClass("invalid");
            $('#tax_classify_box').addClass("form-control");
            $scope.change = true;
            angular.forEach($scope.withHoldingTypes, function (item, index) {
                if (item.name == taxName) {
                    $rootScope.taxClassifyValidation = item.id;
                }
            });

            $scope.funcProvidingValidation($rootScope.incCountryValidation, $rootScope.taxClassifyValidation, $rootScope.exemptCheckBox, $rootScope.disRegardSection);
        }
        angular.forEach($scope.withHoldingTypes, function (item, index) {
            if (item.name == taxName) {
                $scope.maskingToBeDone = item.individual;
                if ($scope.maskingToBeDone == true) {
                    $scope.taxNumberMask = $scope.supplierInfo.registrationNumber;
                    if ($scope.taxNumberMask) {
                        $scope.supplierInfo.registrationNumber = $scope.taxNumberMask.replace('-', '').replace(/\d(?=\d{4})/g, "*");
                    }
                } else {
                    $scope.supplierInfo.registrationNumber = $scope.registrationNoFilledFormSupplier;
                }
            }
        });
    }
    //  



    /*CROSS BORDER */

    /*Providing List start*/
    supplier.getGoodTypes().then(function (data) {
        $scope.supplierInfo.types = [];
        $scope.getGoodTypesNew = [];
        $scope.getGoodTypesRestored = data;
        angular.forEach($scope.getGoodTypesRestored, function (item, index) {
            $scope.getGoodTypesNew.push(item.name);
            $scope.getGoodTypes = $scope.getGoodTypesNew;

        });

    }, function (data) {
//        $scope.loader = false;
        toaster.pop('error', "Good Types Api Server Not Responding");
    });

    /*Providing List ends*/

    /*CROSS BORDER RULE ENGINE VALIDATION START*/
    $scope.crossCountryRuleValidation = function (country) {
        $rootScope.crossCountry = country;
        // $scope.funcCrossBorderProvidingValidation($rootScope.crossCountry,$rootScope.goodTypesValidation);

    }

    //   $scope.selectedtypesArray=[]; 
    //   $scope.onSelected = function (selectedItem) {
    //       angular.forEach($scope.mainGoodTypesList, function(item,index){ 
    //              if(item.name==selectedItem){
    //                  
    //                   $scope.selectedtypesArray.push(item.id);
    //              }
    //
    //            });
    //       
    //       
    //       $scope.change=true;
    //       
    //       
    //       $rootScope.goodTypesValidation=$scope.selectedtypesArray;
    //       console.log($rootScope.goodTypesValidation);
    //       $scope.funcProvidingValidation($rootScope.crossCountry,$rootScope.goodTypesValidation);
    //
    //      }
    //   $scope.removed=function(removedItem){
    //       
    //       angular.forEach($scope.mainGoodTypesList, function(item,index){ 
    //              if(item.name==removedItem){
    //                   $scope.removeId=item.id;
    //              }
    //
    //            });
    //       
    //       
    //       
    //       $scope.change=true;
    //       angular.forEach($scope.selectedtypesArray, function(item,index){
    //           if(item==$scope.removeId){
    //
    //               delete $scope.selectedtypesArray[index];
    //               console.log("final",$scope.selectedtypesArray);
    //               $rootScope.goodTypesValidation=$scope.selectedtypesArray;
    //               $scope.funcProvidingValidation($rootScope.crossCountry,$rootScope.goodTypesValidation);
    //           }
    //           
    //       });
    //   }


    $scope.onSelectedNew = function (typeId) {
        $rootScope.goodNewTypeValidation = typeId;
        console.log("$rootScope.goodTypeValidation", $rootScope.goodNewTypeValidation)
        $scope.funcProvidingValidation($rootScope.incCountryValidation, $rootScope.taxClassifyValidation, $rootScope.exemptCheckBox, $rootScope.disRegardSection);
    }

    /*CROSS BORDER RULE ENGINE VALIDATION END*/

    /*Cross border addbtn and save start*/

    $scope.addMoreCrossBorderBtn = function (supplierInfo) {

        //  

        //          $scope.taxRegDocument = '';
        //          $scope.taxExeDocument ='';


        if (supplierInfo.crossCountry == undefined || supplierInfo.crossCountry == null || supplierInfo.crossCountry == '' || supplierInfo.taxIdentNo == undefined || supplierInfo.taxIdentNo == null || supplierInfo.taxIdentNo == '') {

            toaster.pop('error', "Tax Information Missing", "Please fill tax information");
            return;
        }
        if ($scope.headText == "Document") {
            $scope.taxTable.push({
                countryId: supplierInfo.crossCountry,
                providedProductId: $rootScope.goodNewTypeValidation,
                taxRegistrationNumber: supplierInfo.taxIdentNo,
                documentId: $scope.crossFileName,
                w8DocId: '',
                w8BenDocId: '',
                form8233DocId: '',
                exemptFromWithholdingTax: $scope.supplierInfo.exemptCheckBox,
                exemptDocumentId: ''
            });
        } else if ($scope.headText == "Exempt Document") {
            $scope.taxTable.push({
                countryId: supplierInfo.crossCountry,
                providedProductId: $rootScope.goodNewTypeValidation,
                taxRegistrationNumber: supplierInfo.taxIdentNo,
                documentId: '',
                w8DocId: '',
                w8BenDocId: '',
                form8233DocId: '',
                exemptFromWithholdingTax: $scope.supplierInfo.exemptCheckBox,
                exemptDocumentId: $scope.crossFileName
            });
        } else if ($scope.headText == "w8 Document") {
            $scope.taxTable.push({
                countryId: supplierInfo.crossCountry,
                providedProductId: $rootScope.goodNewTypeValidation,
                taxRegistrationNumber: supplierInfo.taxIdentNo,
                documentId: '',
                w8DocId: $scope.crossFileName,
                w8BenDocId: '',
                form8233DocId: '',
                exemptFromWithholdingTax: $scope.supplierInfo.exemptCheckBox,
                exemptDocumentId: ''
            });
        } else if ($scope.headText == "W8 Ben Document") {
            $scope.taxTable.push({
                countryId: supplierInfo.crossCountry,
                providedProductId: $rootScope.goodNewTypeValidation,
                taxRegistrationNumber: supplierInfo.taxIdentNo,
                documentId: '',
                w8DocId: '',
                w8BenDocId: $scope.crossFileName,
                form8233DocId: '',
                exemptFromWithholdingTax: $scope.supplierInfo.exemptCheckBox,
                exemptDocumentId: ''
            });
        } else if ($scope.headText == "Form 8233 Document") {
            $scope.taxTable.push({
                countryId: supplierInfo.crossCountry,
                providedProductId: $rootScope.goodNewTypeValidation,
                taxRegistrationNumber: supplierInfo.taxIdentNo,
                documentId: '',
                w8DocId: '',
                w8BenDocId: '',
                form8233DocId: $scope.crossFileName,
                exemptFromWithholdingTax: $scope.supplierInfo.exemptCheckBox,
                exemptDocumentId: ''
            });
        }
        //$scope.taxTable.push({countryId:supplierInfo.crossCountry,providedProductId: $rootScope.goodNewTypeValidation, taxRegistrationNumber: supplierInfo.taxIdentNo, documentId: '',w8DocId:'',w8BenDocId:'',form8233DocId:'',exemptFromWithholdingTax:$scope.supplierInfo.exemptCheckBox,taxExemptFileUrl:$scope.taxExemptFileNameUrl, exemptDocumentId: '' });
        $scope.crossBorder = true;
        $scope.fileDownload_CrossDownload = false;
        $scope.crossFileName = "";
        $scope.supplierInfo.crossCountry = '';
        $scope.supplierInfo.types = '';
        $scope.supplierInfo.taxIdentNo = '';
        $scope.supplierInfo.goodTypes = [""];
        $rootScope.goodTypesValidation = [""];
        $scope.fileNameTaxRegDocument = '';
        $scope.fileNameTaxExempt = '';
        //              $scope.fileDownload_TaxRegistration=false;
        $scope.fileDownload_taxExemptDoc = false;
        $scope.supplierInfo.taxRegDocument = '';
        $scope.supplierInfo.taxExeDocument = '';

    }

    /*Cross border addbtn and save ends*/

    /*Cross border ends*/


    /*LEGAL2 STARTS*/
    $scope.loadTaxLegal2 = function (countryCode) {
        $scope.loader = true;
        $scope.supplierInfo.taxClassificationLegal2 = "";
        supplier.withHoldingTaxTypes(countryCode).then(function (data) {
//                $scope.loader = false;
            $scope.withHoldingTypesLegal2 = data;
        }, function (data) {
            $scope.loader = false;
            toaster.pop('error', "Tax Types Api Server Not Responding");
        });

    }
    /*LEGAL2 ENDS*/
});
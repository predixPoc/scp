package com.ge.scp.service;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.ge.scp.util.InvoiceUtility;


@Path("/invoiceDetailsService")
public class InvoiceDetailsService {
	final static Logger logger = Logger.getLogger(InvoiceDetailsService.class);

	
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("/getDetails")
	public Response getScpInvoiceDetails(){
		
		System.out.println("in Response....Test...");
		String vendorGsl=null;
		String invoiceNumber=null;
		String poNumber=null;
		Date invoiceDate=null;
		double amount=0.0;
		
		return Response.ok(InvoiceUtility.getDataTest(vendorGsl, invoiceNumber, poNumber, invoiceDate, amount)).build();
	}
	
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("/getDetails2")
	public Response getScpInvoiceDetails2(
				@QueryParam(value="vendorGsl") String vendorGsl,
				@QueryParam(value="invoiceNumber") String invoiceNumber,
				@QueryParam(value="poNumber") String poNumber,
				@QueryParam(value="invoiceDate") String invoiceDate,
				@QueryParam(value="amount") String amount){
		
		System.out.println("in Response....getScpInvoiceDetails2:");
		
		System.out.println("vendorGsl="+vendorGsl);
		System.out.println("poNumber="+poNumber);
		
		return Response.ok(InvoiceUtility.getData(vendorGsl, invoiceNumber, poNumber, null, 0.0)).build();
	}
	
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("/getDetails3")
	public Response getScpInvoiceDetails3(
				@QueryParam(value="poNumber") String poNumber){
		
		System.out.println("in Response....getScpInvoiceDetails3:");
		System.out.println("poNumber="+poNumber);
		
		return Response.ok(InvoiceUtility.getData("", "", poNumber, null, 0.0)).build();
	}
	
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("/getDetails4")
	public Response getScpInvoiceDetails4(@Context UriInfo info){
		
		String poNumber = info.getQueryParameters().getFirst("poNumber");
		System.out.println("in Response....getScpInvoiceDetails4:");
		System.out.println("poNumber="+poNumber);
		
		return Response.ok(InvoiceUtility.getData("", "", poNumber, null, 0.0)).build();
	}
	
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("/getDetails5")
	public Response getScpInvoiceDetails5(
				@QueryParam(value="vendorGsl") String vendorGsl,
				@QueryParam(value="invoiceNumber") String invoiceNumber,
				@QueryParam(value="poNumber") String poNumber,
				@QueryParam(value="invoiceDate") String invoiceDate,
				@QueryParam(value="amount") double amount){
		
		System.out.println("in Response....getScpInvoiceDetails5:");
		
		System.out.println("vendorGsl="+vendorGsl);
		System.out.println("invoiceNumber="+invoiceNumber);
		System.out.println("poNumber="+poNumber);
		System.out.println("invoiceDate="+invoiceDate);
		System.out.println("amount="+amount);
		
		String pattern3 = "MM/dd/yyyy";
		SimpleDateFormat simpleDateFormat3 = new SimpleDateFormat(pattern3);
		Date date3 = null;

		try {
			if(invoiceDate != null){
				date3 = simpleDateFormat3.parse(invoiceDate);
				System.out.println(date3);
			}
			
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		return Response.ok(InvoiceUtility.getData(vendorGsl, invoiceNumber, poNumber, date3, amount)).build();
	}
	
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("/getDetails6")
	public Response getScpInvoiceDetails6(
				@QueryParam(value="vendorGsl") String vendorGsl,
				@QueryParam(value="invoiceNumber") String invoiceNumber,
				@QueryParam(value="poNumber") String poNumber,
				@QueryParam(value="invoiceDate") String invoiceDate,
				@QueryParam(value="amount") double amount){
		
		System.out.println("in Response....getScpInvoiceDetails6:");
		
		System.out.println("vendorGsl="+vendorGsl);
		System.out.println("invoiceNumber="+invoiceNumber);
		System.out.println("poNumber="+poNumber);
		System.out.println("invoiceDate="+invoiceDate);
		System.out.println("amount="+amount);
		
		String uiInvoiceDtPattern = "MM/dd/yyyy";
		SimpleDateFormat uiInvoiceDateFmt = new SimpleDateFormat(uiInvoiceDtPattern);
		String dbInvoiceDtPattern = "dd-MMM-yy";
		SimpleDateFormat dbInvoiceDateFmt = new SimpleDateFormat(dbInvoiceDtPattern);
		
		Date invoiceDt = null;
		String dbInvoiceDateStr = null;			

		try {
			if(StringUtils.isNotBlank(invoiceDate)){
				invoiceDt = uiInvoiceDateFmt.parse(invoiceDate);
				System.out.println("invoiceDt="+invoiceDt);
				
				dbInvoiceDateStr = dbInvoiceDateFmt.format(invoiceDt);
				System.out.println("dbInvoiceDateStr="+dbInvoiceDateStr);
			}
			
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		return Response.ok(InvoiceUtility.getData6(vendorGsl, invoiceNumber, poNumber, dbInvoiceDateStr, amount)).build();
	}

}

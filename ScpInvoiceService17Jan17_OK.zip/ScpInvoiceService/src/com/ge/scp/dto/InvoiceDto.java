package com.ge.scp.dto;

import java.util.Date;

//@XmlRootElement
public class InvoiceDto {
	
	private String invoiceNumber;	
	private Date invoiceDate;
	private String currency;
	private double amount;
	private String onHold;
	private String status;
	private Date dueDate;
	private String poNumber;

	private String venderGSL;
	private String vendorName;
	
	private String invoiceType;
	private String due;
	//private String status;
	//private String venderGSL;
	
	
	
	public String getInvoiceNumber() {
		return invoiceNumber;
	}
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}
	public Date getInvoiceDate() {
		return invoiceDate;
	}
	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getOnHold() {
		return onHold;
	}
	public void setOnHold(String onHold) {
		this.onHold = onHold;
	}
	/*public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}*/
	public Date getDueDate() {
		return dueDate;
	}
	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}
	public String getPoNumber() {
		return poNumber;
	}
	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}
	/*public String getVendorGsl() {
		return vendorGsl;
	}
	public void setVendorGsl(String vendorGsl) {
		this.vendorGsl = vendorGsl;
	}*/
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getVenderGSL() {
		return venderGSL;
	}
	public void setVenderGSL(String venderGSL) {
		this.venderGSL = venderGSL;
	}
	public String getInvoiceType() {
		return invoiceType;
	}
	public void setInvoiceType(String invoiceType) {
		this.invoiceType = invoiceType;
	}
	public String getDue() {
		return due;
	}
	public void setDue(String due) {
		this.due = due;
	}
	
	@Override
	public String toString() {
		return "InvoiceDto [invoiceNumber=" + invoiceNumber + ", invoiceDate="
				+ invoiceDate + ", currency=" + currency + ", amount=" + amount
				+ ", onHold=" + onHold + ", status=" + status + ", dueDate="
				+ dueDate + ", poNumber=" + poNumber + ", venderGSL="
				+ venderGSL + ", vendorName=" + vendorName + ", invoiceType="
				+ invoiceType + ", due=" + due + "]";
	}
	
}
